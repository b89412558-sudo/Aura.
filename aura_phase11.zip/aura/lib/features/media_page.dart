import 'dart:io';
import 'package:file_picker/file_picker.dart';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:path_provider/path_provider.dart';
import 'package:provider/provider.dart';
import 'package:video_player/video_player.dart';
import '../core/local_store.dart';
import '../core/state.dart';
import '../core/strings.dart';

String _l(BuildContext c, String a, String e) => Localizations.localeOf(c).languageCode == 'ar' ? a : e;

String _kind(String name) {
  final e = name.contains('.') ? name.split('.').last.toLowerCase() : '';
  if (const ['mp4', 'mkv', 'mov', 'avi', 'webm', 'm4v'].contains(e)) return 'video';
  if (const ['png', 'jpg', 'jpeg', 'gif', 'webp'].contains(e)) return 'image';
  if (const ['txt', 'md', 'json', 'csv'].contains(e)) return 'text';
  return 'other';
}

/// الملفات والفيديوهات: تُنسخ إلى مجلد التطبيق وتُحفظ في SQLite فتعمل دون إنترنت.
/// الفيديوهات = مكتبة أفلامك ومسلسلاتك التي تستوردها بنفسك.
class MediaPage extends StatefulWidget {
  const MediaPage({super.key, required this.videos});
  final bool videos;
  @override
  State<MediaPage> createState() => _MediaState();
}

class _MediaState extends State<MediaPage> {
  late Future<List<Map<String, Object?>>> fut;
  LocalStore? store;
  @override
  void initState() { super.initState(); store = context.read<AppState>().store; _load(); }
  void _load() { fut = store?.media(widget.videos) ?? Future.value(<Map<String, Object?>>[]); }

  Future<void> _add() async {
    final r = await FilePicker.platform.pickFiles(allowMultiple: true, type: widget.videos ? FileType.video : FileType.any);
    if (r == null || store == null) return;
    final dir = await getApplicationDocumentsDirectory();
    final md = Directory('${dir.path}/media')..createSync(recursive: true);
    for (final f in r.files) {
      if (f.path == null) continue;
      final dest = '${md.path}/${DateTime.now().millisecondsSinceEpoch}_${f.name}';
      await File(f.path!).copy(dest);
      await store!.addMedia(f.name, dest, _kind(f.name));
    }
    if (mounted) setState(_load);
  }

  Future<void> _open(Map<String, Object?> m) async {
    final path = m['path'] as String, kind = m['kind'] as String;
    if (kind == 'video') { await context.push('/player', extra: {'path': path, 'name': m['name']}); return; }
    if (kind == 'image') {
      await showDialog<void>(context: context, builder: (c) => Dialog(child: InteractiveViewer(child: Image.file(File(path)))));
    } else if (kind == 'text') {
      final txt = await File(path).readAsString();
      if (!mounted) return;
      await showDialog<void>(context: context, builder: (c) => AlertDialog(title: Text(m['name'] as String), content: SingleChildScrollView(child: Text(txt.length > 5000 ? txt.substring(0, 5000) : txt))));
    } else {
      ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(_l(context, 'لا يمكن فتح هذا النوع داخل التطبيق', 'This file type cannot be opened inside the app'))));
    }
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(Str.t(context, widget.videos ? 'videos' : 'files'))),
        floatingActionButton: FloatingActionButton(onPressed: _add, child: const Icon(Icons.add)),
        body: Column(children: [
          if (widget.videos)
            Padding(padding: const EdgeInsets.all(12), child: Text(_l(context, 'أضف أفلامك ومسلسلاتك التي تملكها من جهازك لتُشاهَد دون إنترنت.', 'Add movies and series you own from your device to watch offline.'), style: const TextStyle(fontSize: 12))),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: fut,
              builder: (c, s) {
                if (store == null) return Center(child: Text(_l(c, 'قاعدة البيانات المحلية غير متاحة', 'Local database unavailable')));
                final l = s.data ?? [];
                if (l.isEmpty) return Center(child: Text(_l(c, 'لا توجد ملفات بعد', 'Nothing here yet')));
                return ListView(children: [
                  for (final m in l)
                    ListTile(
                      leading: Icon(m['kind'] == 'video' ? Icons.movie_outlined : (m['kind'] == 'image' ? Icons.image_outlined : Icons.insert_drive_file_outlined)),
                      title: Text(m['name'] as String, maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () => _open(m),
                      trailing: IconButton(
                        icon: const Icon(Icons.delete_outline),
                        onPressed: () async {
                          try { await File(m['path'] as String).delete(); } catch (_) {}
                          await store!.deleteMedia(m['id'] as int);
                          if (mounted) setState(_load);
                        },
                      ),
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

class PlayerPage extends StatefulWidget {
  const PlayerPage({super.key, required this.path, required this.name});
  final String path, name;
  @override
  State<PlayerPage> createState() => _PlayerState();
}

class _PlayerState extends State<PlayerPage> {
  late final VideoPlayerController vc = VideoPlayerController.file(File(widget.path));
  bool ready = false, failed = false;
  @override
  void initState() {
    super.initState();
    vc.initialize().then((_) { if (mounted) setState(() => ready = true); vc.play(); }).catchError((_) { if (mounted) setState(() => failed = true); });
  }
  @override
  void dispose() { vc.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(widget.name, maxLines: 1, overflow: TextOverflow.ellipsis)),
        body: Center(
          child: failed
              ? Text(_l(context, 'تعذّر تشغيل هذا الفيديو', 'Could not play this video'))
              : (!ready
                  ? const CircularProgressIndicator()
                  : Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      AspectRatio(aspectRatio: vc.value.aspectRatio, child: VideoPlayer(vc)),
                      VideoProgressIndicator(vc, allowScrubbing: true),
                      IconButton(
                        iconSize: 40,
                        icon: Icon(vc.value.isPlaying ? Icons.pause : Icons.play_arrow),
                        onPressed: () => setState(() { vc.value.isPlaying ? vc.pause() : vc.play(); }),
                      ),
                    ])),
        ),
      );
}
