import 'dart:math';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/assets.dart';
import '../core/demo.dart';
import '../core/fx.dart';
import '../core/state.dart';
import '../core/strings.dart';
import 'sky.dart';

class HomePage extends StatelessWidget {
  const HomePage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: [
        OrbitSky(height: 230, hintKey: 'hint', onTap: (i) => context.push('/story/$i')),
        for (var i = 0; i < 4; i++) SignalCard(i: i),
      ]);
}

/// بطاقة «إشارة»: المحتوى يملأ البطاقة. ضغطة = شرارة، ضغط مطوّل = قوس التفاعلات.
class SignalCard extends StatefulWidget {
  const SignalCard({super.key, required this.i});
  final int i;
  @override
  State<SignalCard> createState() => _SignalCardState();
}

class _SignalCardState extends State<SignalCard> {
  bool arc = false;
  Offset _center() {
    final rb = context.findRenderObject() as RenderBox;
    return rb.localToGlobal(rb.size.center(Offset.zero));
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.i, key = 'p$i';
    final st = context.watch<AppState>();
    final r = st.rx[key];
    Widget bubble(String k, {double? top, double? start, double? end}) => PositionedDirectional(
          top: top, start: start, end: end,
          child: Container(
            padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 7),
            decoration: BoxDecoration(color: Colors.white24, borderRadius: BorderRadius.circular(16)),
            child: Text(Str.t(context, k), style: const TextStyle(color: Colors.white, fontSize: 12)),
          ),
        );
    return Container(
      margin: const EdgeInsets.fromLTRB(12, 0, 12, 16),
      child: AspectRatio(
        aspectRatio: 3 / 4,
        child: ClipRRect(
          borderRadius: BorderRadius.circular(30),
          child: LayoutBuilder(builder: (c, box) {
            final w = box.maxWidth, h = box.maxHeight;
            return GestureDetector(
              onTap: () {
                if (arc) { setState(() => arc = false); return; }
                final on = r == null;
                st.setRx(key, on ? 'burst' : null);
                if (on) playBurst(context, _center(), 'burst');
              },
              onLongPress: () => setState(() => arc = true),
              child: Stack(children: [
                Positioned.fill(
                  child: DecoratedBox(
                    decoration: BoxDecoration(gradient: LinearGradient(
                        begin: Alignment.topLeft, end: Alignment.bottomRight, colors: kGrad[i % 4])),
                    child: Center(child: Text(kUsers[i].$4, style: const TextStyle(fontSize: 96))),
                  ),
                ),
                PositionedDirectional(
                  top: 12, start: 12,
                  child: Container(
                    padding: const EdgeInsetsDirectional.fromSTEB(4, 4, 12, 4),
                    decoration: BoxDecoration(color: const Color(0x730A0A28), borderRadius: BorderRadius.circular(999)),
                    child: Row(mainAxisSize: MainAxisSize.min, children: [
                      Av(i, 24), const SizedBox(width: 6),
                      Text(kUsers[i].$1, style: const TextStyle(color: Colors.white, fontSize: 13, fontWeight: FontWeight.w600)),
                    ]),
                  ),
                ),
                bubble('c_a', top: h * .26, end: 14),
                bubble('c_b', top: h * .44, start: 14),
                Positioned(
                  left: 0, right: 0, bottom: 0,
                  child: Container(
                    padding: const EdgeInsets.fromLTRB(16, 40, 16, 16),
                    decoration: const BoxDecoration(gradient: LinearGradient(
                        begin: Alignment.topCenter, end: Alignment.bottomCenter,
                        colors: [Colors.transparent, Color(0xBF050519)])),
                    child: Row(crossAxisAlignment: CrossAxisAlignment.end, children: [
                      Expanded(child: Text(Str.t(context, 'cap'), style: const TextStyle(color: Colors.white, fontSize: 15))),
                      Container(
                        padding: const EdgeInsets.symmetric(horizontal: 12, vertical: 4),
                        decoration: BoxDecoration(color: const Color(0x3300E5FF), borderRadius: BorderRadius.circular(999),
                            border: Border.all(color: const Color(0x8000E5FF))),
                        child: Row(mainAxisSize: MainAxisSize.min, children: [
                          Text('${120 + i * 37 + (r != null ? 1 : 0)} ', style: const TextStyle(color: Colors.white, fontSize: 13)),
                          Emo(r ?? 'burst', 20),
                        ]),
                      ),
                    ]),
                  ),
                ),
                if (arc)
                  Positioned.fill(
                    child: Container(
                      color: const Color(0x8C050519),
                      child: Stack(children: [
                        for (var k = 0; k < kReacts.length; k++)
                          Positioned(
                            left: w / 2 + 112 * sin((k - 2) * 38 * pi / 180) - 26,
                            top: h - 70 - 112 * cos((k - 2) * 38 * pi / 180) - 26,
                            child: GestureDetector(
                              onTap: () {
                                final id = kReacts[k];
                                final ctr = _center();
                                setState(() => arc = false);
                                st.setRx(key, id);
                                playBurst(context, ctr, id);
                              },
                              child: Container(
                                width: 52, height: 52, alignment: Alignment.center,
                                decoration: BoxDecoration(shape: BoxShape.circle, color: Colors.white24,
                                    border: Border.all(color: Colors.white54),
                                    boxShadow: const [BoxShadow(color: Color(0x8000E5FF), blurRadius: 16)]),
                                child: Emo(kReacts[k], 36),
                              ),
                            ),
                          ),
                      ]),
                    ),
                  ),
              ]),
            );
          }),
        ),
      ),
    );
  }
}
