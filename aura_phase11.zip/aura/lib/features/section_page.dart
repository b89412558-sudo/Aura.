import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/strings.dart';

/// صفحة مستقلة لكل قسم. تُستبدل بالتنفيذ الفعلي في المراحل التالية.
class SectionPage extends StatelessWidget {
  const SectionPage({super.key, required this.id});
  final String id;
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: BackButton(onPressed: () => context.pop()),
          title: Text(Str.t(context, id)),
        ),
        body: Center(child: Padding(
          padding: const EdgeInsets.all(24),
          child: Text(Str.t(context, 'pending'), textAlign: TextAlign.center),
        )),
      );
}
