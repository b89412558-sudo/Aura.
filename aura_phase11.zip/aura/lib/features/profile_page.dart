import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/auth_service.dart';
import '../core/chat_repo.dart';
import '../core/demo.dart';
import '../core/strings.dart';
import '../core/theme.dart';

class ProfilePage extends StatelessWidget {
  const ProfilePage({super.key});
  @override
  Widget build(BuildContext context) {
    String t(String k) => Str.t(context, k);
    Widget stat(String n, String l) => Column(children: [
          Text(n, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)), Text(l)]);
    return Scaffold(
      appBar: AppBar(
        leading: BackButton(onPressed: () => context.pop()),
        title: Text(t('profile')),
        actions: [
          if (AuthService.ready)
            IconButton(
              tooltip: t('logout'), icon: const Icon(Icons.logout),
              onPressed: () async { await ChatRepo.stop(); await AuthService.signOut(); if (context.mounted) context.go('/auth'); },
            ),
        ],
      ),
      body: ListView(children: [
        Stack(clipBehavior: Clip.none, children: [
          Container(height: 130, decoration: const BoxDecoration(gradient: LinearGradient(colors: [AuraColors.blue, AuraColors.violet, AuraColors.cyan]))),
          const PositionedDirectional(start: 16, bottom: -40, child: Av(-1, 84)),
        ]),
        const SizedBox(height: 48),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 16),
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Text(AuthService.displayName ?? 'AURA User', style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            Text('@${AuthService.username ?? 'aura_user'}'),
            const SizedBox(height: 8),
            Text(t('bio')),
            const SizedBox(height: 12),
            Row(children: [stat('4', t('posts')), const SizedBox(width: 24), stat('${kUsers.length}', t('fr'))]),
          ]),
        ),
      ]),
    );
  }
}
