import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/assets.dart';
import '../core/demo.dart';
import '../core/state.dart';
import '../core/strings.dart';
import 'sky.dart';

class MessagesPage extends StatelessWidget {
  const MessagesPage({super.key});
  @override
  Widget build(BuildContext context) => ListView(children: const [Constellation()]);
}

class ChatPage extends StatefulWidget {
  const ChatPage({super.key, required this.i});
  final int i;
  @override
  State<ChatPage> createState() => _ChatPageState();
}

class _ChatPageState extends State<ChatPage> {
  final ctrl = TextEditingController();
  bool tray = false;
  @override
  void dispose() { ctrl.dispose(); super.dispose(); }

  void _send(String text) {
    context.read<AppState>().send(widget.i, text, Str.t(context, 'hi'));
  }

  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final msgs = st.chats[widget.i] ?? [(false, Str.t(context, 'hi'))];
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(uname(context, widget.i))),
      body: Column(children: [
        Expanded(
          child: ListView(padding: const EdgeInsets.all(12), children: [
            for (final (me, text) in msgs)
              Align(
                alignment: me ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                child: stickerId(text) != null
                    ? Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Emo(stickerId(text)!, 84))
                    : Container(
                        margin: const EdgeInsets.symmetric(vertical: 3),
                        padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                        decoration: BoxDecoration(
                            color: me ? cs.primary : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
                        child: Text(text, style: TextStyle(color: me ? cs.onPrimary : null)),
                      ),
              ),
          ]),
        ),
        if (tray)
          Container(
            width: double.infinity,
            padding: const EdgeInsets.all(8),
            child: Wrap(spacing: 6, runSpacing: 6, children: [
              for (final k in kEmoji)
                GestureDetector(
                  onTap: () { _send(':$k:'); setState(() => tray = false); },
                  child: Padding(padding: const EdgeInsets.all(4), child: Emo(k, 46)),
                ),
            ]),
          ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              GestureDetector(onTap: () => setState(() => tray = !tray), child: const Padding(padding: EdgeInsets.all(4), child: Emo('star_eyes', 32))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: ctrl,
                  onSubmitted: (v) { if (v.trim().isNotEmpty) { _send(v.trim()); ctrl.clear(); } },
                  decoration: InputDecoration(hintText: Str.t(context, 'type'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24)))))),
              IconButton(icon: const Icon(Icons.send), onPressed: () {
                final v = ctrl.text.trim();
                if (v.isNotEmpty) { _send(v); ctrl.clear(); }
              }),
            ]),
          ),
        ),
      ]),
    );
  }
}
