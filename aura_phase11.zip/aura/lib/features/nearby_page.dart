import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/auth_service.dart';
import '../core/ble_service.dart';
import '../core/chat_repo.dart';
import '../core/settings.dart';
import '../core/social_service.dart';
import '../core/strings.dart';

String _l(BuildContext c, String a, String e) => Localizations.localeOf(c).languageCode == 'ar' ? a : e;

class NearbyPage extends StatelessWidget {
  const NearbyPage({super.key});
  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppSettings>();
    final ok = AuthService.ready && AuthService.user != null;
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(Str.t(context, 'nearby'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        if (!ok) Text(_l(context, 'سجّل الدخول أولاً (يحتاج إنترنت مرة واحدة) ثم أضف أصدقاءك قبل استخدام Bluetooth.', 'Sign in first (needs internet once), then add friends before using Bluetooth.')),
        SwitchListTile(
          value: st.nearby && ok,
          onChanged: ok ? (v) async { st.setNearby(v); if (v) { await ChatRepo.start(); await BleService.start(); } else { await BleService.stop(); } } : null,
          title: Text(_l(context, 'التواصل عبر Bluetooth', 'Bluetooth messaging')),
          subtitle: Text(_l(context, 'مطفأ افتراضياً لأنه يستهلك البطارية.', 'Off by default because it uses battery.')),
        ),
        ValueListenableBuilder<String>(valueListenable: BleService.status, builder: (c, v, _) => ListTile(title: Text(_l(c, 'الحالة', 'Status')), subtitle: Text(v))),
        ValueListenableBuilder<List<String>>(
          valueListenable: BleService.nearby,
          builder: (c, v, _) => ListTile(title: Text(_l(c, 'أصدقاء قريبون الآن', 'Friends nearby now')), subtitle: Text(v.isEmpty ? _l(c, 'لا أحد', 'None') : v.map((x) => '@$x').join('، '))),
        ),
        if (ok && ChatRepo.store != null)
          FutureBuilder<int>(
            future: ChatRepo.store!.pendingCount(SocialService.me),
            builder: (c, s) => ListTile(title: Text(_l(c, 'رسائل بانتظار الإرسال', 'Messages waiting to send')), subtitle: Text('${s.data ?? 0}')),
          ),
        const Divider(),
        Text(_l(context,
            'ما يجب أن تعرفه:\n• المدى القريب فقط (نحو 10 أمتار، وقد يصل إلى عشرات الأمتار في مكان مكشوف، ويقل داخل المباني).\n• تعمل بين أصدقاء مقبولين فقط، ويجب أن يكون الطرفان قد فتحا التطبيق مرة بإنترنت لتبادل المفاتيح.\n• حدّ الرسالة 200 حرف عبر Bluetooth؛ الأطول تُرسل بالإنترنت فقط.\n• في iPhone يتقيّد العمل في الخلفية، فافتح التطبيق على الجهازين.\n• لا يوجد ترحيل عبر أجهزة وسيطة بعد.',
            'What to know:\n• Short range only (about 10 m, up to tens of meters in the open, less indoors).\n• Works between accepted friends only, and both must have opened the app once with internet to exchange keys.\n• Bluetooth messages are limited to 200 characters; longer ones go by internet only.\n• On iPhone, background use is restricted; keep the app open on both devices.\n• No relay through intermediate devices yet.'),
            style: const TextStyle(fontSize: 13)),
      ]),
    );
  }
}
