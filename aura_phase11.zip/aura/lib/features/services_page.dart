import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/assets.dart';
import '../core/strings.dart';

const _svc = ['ai', 'search', 'images', 'games', 'wiki', 'notes', 'files', 'videos', 'nearby'];

class ServicesPage extends StatelessWidget {
  const ServicesPage({super.key});
  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(Str.t(context, 'services'))),
        body: GridView.extent(
          maxCrossAxisExtent: 170, padding: const EdgeInsets.all(16), mainAxisSpacing: 12, crossAxisSpacing: 12,
          children: [
            for (final id in _svc)
              InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () => context.push(id == 'ai' ? '/ai' : '/s/$id'),
                child: Ink(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: const RadialGradient(center: Alignment(0, -.3), colors: [Color(0xFF2A1D6E), Color(0xFF0A0A1E)]),
                    border: Border.all(color: const Color(0x4DC9B8FF)),
                  ),
                  child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                    id == 'ai' ? Image.asset('assets/logo/aura_icon.png', width: 44, height: 44) : Ic(id, 44),
                    const SizedBox(height: 8),
                    Text(Str.t(context, id), textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFECEAFF))),
                  ]),
                ),
              ),
          ],
        ),
      );
}
