import 'dart:async';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/local_store.dart';
import '../core/state.dart';
import '../core/strings.dart';

String _l(BuildContext c, String a, String e) => Localizations.localeOf(c).languageCode == 'ar' ? a : e;

/// الملاحظات: تُحفظ في SQLite على الجهاز وتعمل دون إنترنت.
class NotesPage extends StatefulWidget {
  const NotesPage({super.key});
  @override
  State<NotesPage> createState() => _NotesState();
}

class _NotesState extends State<NotesPage> {
  String q = '';
  late Future<List<Map<String, Object?>>> fut;
  LocalStore? store;
  @override
  void initState() { super.initState(); store = context.read<AppState>().store; _load(); }
  void _load() { fut = store?.notes() ?? Future.value(<Map<String, Object?>>[]); }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(Str.t(context, 'notes'))),
        floatingActionButton: FloatingActionButton(
          onPressed: () async { await context.push('/note/0'); setState(_load); },
          child: const Icon(Icons.add),
        ),
        body: Column(children: [
          Padding(
            padding: const EdgeInsets.all(12),
            child: TextField(
              decoration: InputDecoration(hintText: _l(context, 'بحث في الملاحظات', 'Search notes'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)))),
              onChanged: (v) => setState(() => q = v),
            ),
          ),
          Expanded(
            child: FutureBuilder<List<Map<String, Object?>>>(
              future: fut,
              builder: (c, s) {
                if (store == null) { return Center(child: Text(_l(c, 'قاعدة البيانات المحلية غير متاحة', 'Local database unavailable'))); }
                final all = s.data ?? [];
                final l = all.where((n) => q.trim().isEmpty || '${n['title']} ${n['body']}'.toLowerCase().contains(q.toLowerCase().trim())).toList();
                if (l.isEmpty) { return Center(child: Text(_l(c, 'لا توجد ملاحظات', 'No notes'))); }
                return ListView(children: [
                  for (final n in l)
                    ListTile(
                      leading: const Icon(Icons.edit_note),
                      title: Text(((n['title'] as String).isEmpty ? (n['body'] as String).split('\n').first : n['title'] as String), maxLines: 1, overflow: TextOverflow.ellipsis),
                      subtitle: Text(n['body'] as String, maxLines: 1, overflow: TextOverflow.ellipsis),
                      onTap: () async { await context.push('/note/${n['id']}'); setState(_load); },
                    ),
                ]);
              },
            ),
          ),
        ]),
      );
}

class NoteEditor extends StatefulWidget {
  const NoteEditor({super.key, required this.id});
  final int id; // 0 = ملاحظة جديدة
  @override
  State<NoteEditor> createState() => _NoteEditorState();
}

class _NoteEditorState extends State<NoteEditor> {
  final t = TextEditingController(), b = TextEditingController();
  int? id;
  LocalStore? store;
  Timer? deb;
  bool deleted = false;

  @override
  void initState() {
    super.initState();
    store = context.read<AppState>().store;
    id = widget.id == 0 ? null : widget.id;
    _load();
  }

  Future<void> _load() async {
    if (id == null || store == null) return;
    final rows = await store!.notes();
    for (final r in rows) {
      if (r['id'] == id) { t.text = r['title'] as String; b.text = r['body'] as String; }
    }
    if (mounted) setState(() {});
  }

  Future<void> _persist(String tt, String bb) async {
    if (deleted || (tt.trim().isEmpty && bb.trim().isEmpty) || store == null) return;
    id = await store!.saveNote(id, tt, bb);
  }

  void _changed(String _) { deb?.cancel(); final tt = t.text, bb = b.text; deb = Timer(const Duration(milliseconds: 500), () => _persist(tt, bb)); }

  @override
  void dispose() {
    deb?.cancel();
    _persist(t.text, b.text); // حفظ أخير عند الخروج
    t.dispose();
    b.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) => Scaffold(
        appBar: AppBar(
          leading: BackButton(onPressed: () => context.pop()),
          title: Text(_l(context, 'ملاحظة', 'Note')),
          actions: [
            IconButton(
              tooltip: _l(context, 'حذف', 'Delete'), icon: const Icon(Icons.delete_outline),
              onPressed: () async {
                deleted = true;
                if (id != null) { await store?.deleteNote(id!); }
                if (context.mounted) context.pop();
              },
            ),
          ],
        ),
        body: Padding(
          padding: const EdgeInsets.all(12),
          child: Column(children: [
            TextField(controller: t, onChanged: _changed, decoration: InputDecoration(hintText: _l(context, 'العنوان', 'Title'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12))))),
            const SizedBox(height: 8),
            Expanded(
              child: TextField(
                controller: b, onChanged: _changed, maxLines: null, expands: true, textAlignVertical: TextAlignVertical.top,
                decoration: InputDecoration(hintText: _l(context, 'اكتب هنا...', 'Write here...'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)))),
              ),
            ),
          ]),
        ),
      );
}
