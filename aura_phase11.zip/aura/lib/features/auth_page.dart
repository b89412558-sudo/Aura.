import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/assets.dart';
import '../core/auth_service.dart';
import '../core/strings.dart';

enum _Step { phone, code, username }

class AuthPage extends StatefulWidget {
  const AuthPage({super.key});
  @override
  State<AuthPage> createState() => _AuthPageState();
}

class _AuthPageState extends State<AuthPage> {
  late _Step step = AuthService.user != null ? _Step.username : _Step.phone;
  final phone = TextEditingController(), code = TextEditingController(), uname = TextEditingController(), disp = TextEditingController();
  String? vid, err;
  bool busy = false;

  Future<void> _run(Future<void> Function() f) async {
    setState(() { busy = true; err = null; });
    try { await f(); } catch (_) { err = Str.t(context, 'err_generic'); }
    if (mounted) setState(() => busy = false);
  }

  Future<void> _afterLogin() async {
    await AuthService.refreshUsername();
    if (!mounted) return;
    if (AuthService.hasUsername) { context.go('/'); } else { setState(() => step = _Step.username); }
  }

  @override
  Widget build(BuildContext context) {
    String t(String k) => Str.t(context, k);
    Widget field(TextEditingController c, String label, {String? hint, TextInputType? kb, bool ltr = false}) => Padding(
          padding: const EdgeInsets.only(top: 12),
          child: TextField(
            controller: c, keyboardType: kb, textDirection: ltr ? TextDirection.ltr : null,
            decoration: InputDecoration(labelText: label, helperText: hint, border: const OutlineInputBorder()),
          ),
        );
    return Scaffold(
      body: SafeArea(
        child: Center(
          child: SingleChildScrollView(
            padding: const EdgeInsets.all(24),
            child: ConstrainedBox(
              constraints: const BoxConstraints(maxWidth: 420),
              child: Column(mainAxisSize: MainAxisSize.min, crossAxisAlignment: CrossAxisAlignment.stretch, children: [
                Center(child: logo(96)),
                const SizedBox(height: 12),
                Center(child: Text(t('auth_title'), style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
                if (step == _Step.phone) ...[
                  field(phone, t('phone'), hint: t('phone_h'), kb: TextInputType.phone, ltr: true),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: busy ? null : () => _run(() async {
                      await AuthService.sendCode(phone.text.trim(),
                          onSent: (v) { if (mounted) setState(() { vid = v; step = _Step.code; }); },
                          onError: (e) { if (mounted) setState(() => err = e); },
                          onAuto: _afterLogin);
                    }),
                    child: Text(t('send_code')),
                  ),
                ],
                if (step == _Step.code) ...[
                  field(code, t('code'), kb: TextInputType.number, ltr: true),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: busy ? null : () => _run(() async { await AuthService.confirm(vid!, code.text.trim()); await _afterLogin(); }),
                    child: Text(t('verify')),
                  ),
                ],
                if (step == _Step.username) ...[
                  field(disp, t('display')),
                  field(uname, t('username'), hint: t('username_h'), ltr: true),
                  const SizedBox(height: 16),
                  FilledButton(
                    onPressed: busy ? null : () => _run(() async {
                      final r = await AuthService.claimUsername(uname.text, disp.text);
                      if (r == null) { if (mounted) context.go('/'); }
                      else { err = t(r == 'taken' ? 'err_taken' : r == 'invalid' ? 'err_invalid' : 'err_generic'); }
                    }),
                    child: Text(t('continue')),
                  ),
                ],
                if (busy) const Padding(padding: EdgeInsets.only(top: 16), child: LinearProgressIndicator()),
                if (err != null) Padding(padding: const EdgeInsets.only(top: 12), child: Text(err!, style: TextStyle(color: Theme.of(context).colorScheme.error))),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
