import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/demo.dart';
import '../core/fx.dart';
import '../core/state.dart';
import '../core/strings.dart';

/// مقاطع عمودية. سحب جانبي: يميناً شرارة، يساراً رد. مؤشر دائري حول الشعار.
class ReelsPage extends StatefulWidget {
  const ReelsPage({super.key});
  @override
  State<ReelsPage> createState() => _ReelsPageState();
}

class _ReelsPageState extends State<ReelsPage> {
  final pc = PageController();
  int cur = 0;
  @override
  void dispose() { pc.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) => PageView.builder(
        controller: pc, scrollDirection: Axis.vertical, itemCount: 4,
        onPageChanged: (v) => setState(() => cur = v),
        itemBuilder: (c, i) => Reel(
          i: i, active: i == cur,
          onDone: () { if (i < 3) pc.nextPage(duration: const Duration(milliseconds: 350), curve: Curves.easeOut); },
        ),
      );
}

class Reel extends StatefulWidget {
  const Reel({super.key, required this.i, required this.active, required this.onDone});
  final int i;
  final bool active;
  final VoidCallback onDone;
  @override
  State<Reel> createState() => _ReelState();
}

class _ReelState extends State<Reel> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 8))
    ..addStatusListener((s) { if (s == AnimationStatus.completed) widget.onDone(); });
  @override
  void initState() { super.initState(); if (widget.active) ac.forward(); }
  @override
  void didUpdateWidget(covariant Reel o) {
    super.didUpdateWidget(o);
    if (widget.active && !o.active) { ac.forward(from: 0); }
    if (!widget.active && o.active) { ac.stop(); ac.value = 0; }
  }
  @override
  void dispose() { ac.dispose(); super.dispose(); }

  void _reply() {
    final c = TextEditingController();
    final st = context.read<AppState>();
    final hello = Str.t(context, 'hi');
    final msg = Str.t(context, 'sentm');
    showModalBottomSheet(
      context: context, isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: EdgeInsets.fromLTRB(12, 12, 12, MediaQuery.of(ctx).viewInsets.bottom + 12),
        child: Row(children: [
          Expanded(child: TextField(controller: c, autofocus: true,
              decoration: InputDecoration(hintText: Str.t(ctx, 'rph'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24)))))),
          IconButton(icon: const Icon(Icons.send), onPressed: () {
            final v = c.text.trim();
            if (v.isEmpty) return;
            st.send(widget.i, v, hello);
            Navigator.pop(ctx);
            ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg), duration: const Duration(seconds: 1)));
          }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    final i = widget.i;
    return GestureDetector(
      onHorizontalDragEnd: (d) {
        final v = d.primaryVelocity ?? 0;
        if (v > 300) {
          final rb = context.findRenderObject() as RenderBox;
          playBurst(context, rb.localToGlobal(rb.size.center(Offset.zero)), 'burst');
        } else if (v < -300) {
          _reply();
        }
      },
      child: Container(
        decoration: BoxDecoration(gradient: LinearGradient(
            begin: Alignment.topCenter, end: Alignment.bottomCenter,
            colors: [kGrad[i % 4][0], kGrad[i % 4][1], const Color(0xFF0A0A1E)])),
        child: Stack(children: [
          Center(child: Text(kUsers[i].$4, style: const TextStyle(fontSize: 80))),
          PositionedDirectional(
            top: 16, end: 16,
            child: SizedBox(
              width: 50, height: 50,
              child: AnimatedBuilder(
                animation: ac,
                builder: (_, __) => Stack(alignment: Alignment.center, children: [
                  SizedBox(width: 50, height: 50, child: CircularProgressIndicator(
                      value: ac.value, strokeWidth: 3, color: const Color(0xFF00E5FF), backgroundColor: Colors.white24)),
                  Image.asset('assets/logo/aura_icon.png', width: 32, height: 32),
                ]),
              ),
            ),
          ),
          PositionedDirectional(
            start: 14, bottom: 40,
            child: Text('@${kUsers[i].$1}\n${Str.t(context, 'cap')}', style: const TextStyle(color: Colors.white, fontSize: 15)),
          ),
          Positioned(
            left: 0, right: 0, bottom: 12,
            child: Text(Str.t(context, 'swh'), textAlign: TextAlign.center,
                style: const TextStyle(color: Colors.white70, fontSize: 12)),
          ),
        ]),
      ),
    );
  }
}
