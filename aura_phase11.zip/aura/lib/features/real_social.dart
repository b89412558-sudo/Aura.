import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/assets.dart';
import '../core/chat_repo.dart';
import '../core/social_service.dart';
import '../core/strings.dart';

String _l(BuildContext c, String a, String e) => Localizations.localeOf(c).languageCode == 'ar' ? a : e;

Widget _av(String name, double s) => CircleAvatar(
      radius: s / 2, backgroundColor: const Color(0xFF7B3FE4),
      child: Text(name.isEmpty ? '?' : name[0].toUpperCase(), style: TextStyle(color: Colors.white, fontSize: s / 2.4, fontWeight: FontWeight.bold)),
    );

/// الأصدقاء الحقيقيون: بحث باسم المستخدم + طلبات + قائمة + حظر/إبلاغ.
class RealFriendsPage extends StatefulWidget {
  const RealFriendsPage({super.key});
  @override
  State<RealFriendsPage> createState() => _RealFriendsState();
}

class _RealFriendsState extends State<RealFriendsPage> {
  final c = TextEditingController();
  @override
  void dispose() { c.dispose(); super.dispose(); }

  Future<void> _add() async {
    final r = await SocialService.sendRequest(c.text);
    if (!mounted) return;
    final msg = switch (r) {
      null => _l(context, 'تم إرسال طلب الصداقة', 'Friend request sent'),
      'notfound' => _l(context, 'لا يوجد مستخدم بهذا الاسم', 'No user with that username'),
      'self' => _l(context, 'هذا اسمك أنت', 'That is your own username'),
      'exists' => _l(context, 'يوجد طلب أو صداقة بالفعل', 'A request or friendship already exists'),
      _ => _l(context, 'تعذّر الإرسال، تأكد من الاتصال', 'Could not send, check your connection'),
    };
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(msg)));
    if (r == null) c.clear();
  }

  @override
  Widget build(BuildContext context) => ListView(children: [
        Padding(
          padding: const EdgeInsets.all(12),
          child: Row(children: [
            Expanded(child: TextField(controller: c, textDirection: TextDirection.ltr, onSubmitted: (_) => _add(),
                decoration: InputDecoration(hintText: _l(context, 'أضف صديقاً باسم المستخدم', 'Add a friend by username'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)))))),
            const SizedBox(width: 8),
            FilledButton(onPressed: _add, child: Text(Str.t(context, 'add'))),
          ]),
        ),
        StreamBuilder<List<RequestInfo>>(
          stream: SocialService.incoming(),
          builder: (c, s) {
            final l = s.data ?? [];
            if (l.isEmpty) return const SizedBox();
            return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
              Padding(padding: const EdgeInsets.fromLTRB(16, 8, 16, 0), child: Text(Str.t(c, 'req'))),
              for (final r in l)
                ListTile(
                  leading: _av(r.from, 44), title: Text('@${r.from}'),
                  trailing: Row(mainAxisSize: MainAxisSize.min, children: [
                    FilledButton(onPressed: () => SocialService.accept(r.pairId), child: Text(Str.t(c, 'accept'))),
                    const SizedBox(width: 6),
                    OutlinedButton(onPressed: () => SocialService.removeFriendship(r.pairId), child: Text(Str.t(c, 'decline'))),
                  ]),
                ),
              const Divider(),
            ]);
          },
        ),
        StreamBuilder<List<FriendInfo>>(
          stream: SocialService.friends(),
          builder: (c, s) {
            final l = s.data ?? [];
            if (l.isEmpty) return Padding(padding: const EdgeInsets.all(32), child: Center(child: Text(_l(c, 'لا أصدقاء بعد. أضف صديقاً باسم المستخدم.', 'No friends yet. Add one by username.'))));
            return Column(children: [
              for (final f in l)
                ListTile(
                  leading: _av(f.username, 44), title: Text('@${f.username}'),
                  onTap: () => context.push('/rchat/${f.pairId}', extra: f.username),
                  trailing: PopupMenuButton<String>(
                    onSelected: (v) async {
                      if (v == 'remove') { await SocialService.removeFriendship(f.pairId); }
                      if (v == 'block') { await SocialService.block(f); }
                      if (v == 'report') {
                        await SocialService.report(f.uid, 'user_report');
                        if (c.mounted) ScaffoldMessenger.of(c).showSnackBar(SnackBar(content: Text(_l(c, 'تم إرسال البلاغ', 'Report sent'))));
                      }
                    },
                    itemBuilder: (_) => [
                      PopupMenuItem(value: 'remove', child: Text(_l(c, 'حذف الصديق', 'Remove friend'))),
                      PopupMenuItem(value: 'block', child: Text(_l(c, 'حظر', 'Block'))),
                      PopupMenuItem(value: 'report', child: Text(_l(c, 'إبلاغ', 'Report'))),
                    ],
                  ),
                ),
            ]);
          },
        ),
      ]);
}

/// قائمة محادثات الأصدقاء الحقيقيين.
class RealMessagesPage extends StatelessWidget {
  const RealMessagesPage({super.key});
  @override
  Widget build(BuildContext context) => StreamBuilder<List<FriendInfo>>(
        stream: SocialService.friends(),
        builder: (c, s) {
          final l = s.data ?? [];
          if (l.isEmpty) return Center(child: Text(_l(c, 'أضف أصدقاء أولاً من تبويب الأصدقاء', 'Add friends first from the Friends tab')));
          return ListView(children: [
            for (final f in l)
              ListTile(leading: _av(f.username, 48), title: Text('@${f.username}'), onTap: () => context.push('/rchat/${f.pairId}', extra: f.username)),
          ]);
        },
      );
}

class RealChatPage extends StatefulWidget {
  const RealChatPage({super.key, required this.pid, required this.name});
  final String pid, name;
  @override
  State<RealChatPage> createState() => _RealChatState();
}

class _RealChatState extends State<RealChatPage> {
  final ctrl = TextEditingController();
  bool tray = false;
  @override
  void dispose() { ctrl.dispose(); super.dispose(); }
  void _send(String t) { if (t.trim().isNotEmpty) ChatRepo.send(widget.pid, t.trim()); }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text('@${widget.name}')),
      body: Column(children: [
        Expanded(
          child: StreamBuilder<List<ChatMsg>>(
            stream: ChatRepo.watch(widget.pid),
            builder: (c, s) {
              final l = s.data ?? [];
              return ListView(padding: const EdgeInsets.all(12), children: [
                for (final m in l)
                  Align(
                    alignment: m.from == SocialService.me ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                    child: stickerId(m.text) != null
                        ? Padding(padding: const EdgeInsets.symmetric(vertical: 4), child: Emo(stickerId(m.text)!, 84))
                        : Container(
                            margin: const EdgeInsets.symmetric(vertical: 3),
                            padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                            decoration: BoxDecoration(color: m.from == SocialService.me ? cs.primary : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
                            child: Row(mainAxisSize: MainAxisSize.min, children: [
                              Flexible(child: Text(m.text, style: TextStyle(color: m.from == SocialService.me ? cs.onPrimary : null))),
                              if (m.from == SocialService.me) Padding(padding: const EdgeInsetsDirectional.only(start: 6), child: Icon(m.status == 'server' ? Icons.done : (m.status == 'ble' ? Icons.bluetooth : Icons.schedule), size: 12, color: cs.onPrimary)),
                            ]),
                          ),
                  ),
              ]);
            },
          ),
        ),
        if (tray)
          Padding(
            padding: const EdgeInsets.all(8),
            child: Wrap(spacing: 6, runSpacing: 6, children: [
              for (final k in kEmoji) GestureDetector(onTap: () { _send(':$k:'); setState(() => tray = false); }, child: Padding(padding: const EdgeInsets.all(4), child: Emo(k, 46))),
            ]),
          ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              GestureDetector(onTap: () => setState(() => tray = !tray), child: const Padding(padding: EdgeInsets.all(4), child: Emo('star_eyes', 32))),
              const SizedBox(width: 6),
              Expanded(child: TextField(controller: ctrl, onSubmitted: (v) { _send(v); ctrl.clear(); },
                  decoration: InputDecoration(hintText: Str.t(context, 'type'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24)))))),
              IconButton(icon: const Icon(Icons.send), onPressed: () { _send(ctrl.text); ctrl.clear(); }),
            ]),
          ),
        ),
      ]),
    );
  }
}
