import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/demo.dart';
import '../core/state.dart';

class StoryPage extends StatefulWidget {
  const StoryPage({super.key, required this.i});
  final int i;
  @override
  State<StoryPage> createState() => _StoryPageState();
}

class _StoryPageState extends State<StoryPage> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 5))
    ..addStatusListener((s) { if (s == AnimationStatus.completed && mounted) context.pop(); })
    ..forward();
  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) { if (mounted) context.read<AppState>().markSeen(widget.i); });
  }
  @override
  void dispose() { ac.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final i = widget.i;
    return GestureDetector(
      onTap: () => context.pop(),
      child: Scaffold(
        body: Container(
          decoration: BoxDecoration(gradient: LinearGradient(
              begin: Alignment.topCenter, end: Alignment.bottomCenter,
              colors: [kGrad[i % 4][0], kGrad[i % 4][1], const Color(0xFF0A0A1E)])),
          child: SafeArea(
            child: Stack(children: [
              Center(child: Text(kUsers[i].$4, style: const TextStyle(fontSize: 90))),
              Padding(
                padding: const EdgeInsets.all(12),
                child: Column(children: [
                  AnimatedBuilder(animation: ac, builder: (_, __) =>
                      LinearProgressIndicator(value: ac.value, minHeight: 3, backgroundColor: Colors.white24, color: Colors.white)),
                  const SizedBox(height: 10),
                  Row(children: [Av(i, 34), const SizedBox(width: 8),
                    Text(kUsers[i].$1, style: const TextStyle(color: Colors.white, fontWeight: FontWeight.bold))]),
                ]),
              ),
            ]),
          ),
        ),
      ),
    );
  }
}
