import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/assets.dart';
import '../core/demo.dart';
import '../core/state.dart';
import '../core/strings.dart';

/// AURA AI: يعمل محلياً على بيانات التطبيق (تجريبي). الذكاء الاصطناعي السحابي لم يُربط بعد.
class AiPage extends StatefulWidget {
  const AiPage({super.key});
  @override
  State<AiPage> createState() => _AiPageState();
}

class _AiPageState extends State<AiPage> {
  final msgs = <(bool, String)>[];
  final ctrl = TextEditingController();
  @override
  void dispose() { ctrl.dispose(); super.dispose(); }

  String _answer(String k) {
    final st = context.read<AppState>();
    String t(String x) => Str.t(context, x);
    switch (k) {
      case 'c1':
        final l = <String>[];
        st.chats.forEach((i, m) {
          if (m.length > 1) { l.add('• ${uname(context, i)}: ${m.length - 1} ${t('msgs')} — “${stickerId(m.last.$2) != null ? t('sticker') : m.last.$2}”'); }
        });
        return l.isEmpty ? t('nochat') : l.join('\n');
      case 'c2':
        if (st.rx.isNotEmpty) {
          final i = int.tryParse(st.rx.keys.last.substring(1)) ?? 1;
          return '${t('likedN')}: ${st.rx.length}\n${t('watch')} @${kUsers[i].$1} ${kUsers[i].$4}';
        }
        return '${t('watch0')} @${kUsers[1].$1} ${kUsers[1].$4}';
      case 'c3':
        if (st.chats.isEmpty) return t('nochat');
        final i = st.chats.keys.last;
        return '${t('reply')} ${uname(context, i)}:\n“${Str.isRtl(Localizations.localeOf(context)) ? 'تمام، نتكلم بعد قليل 👍' : 'Sounds good, talk soon 👍'}”';
      default:
        return t('aidemo');
    }
  }

  void _ask(String? k, [String? free]) {
    final q = k != null ? Str.t(context, k) : (free ?? '').trim();
    if (q.isEmpty) return;
    setState(() { msgs..add((true, q))..add((false, _answer(k ?? ''))); });
    ctrl.clear();
  }

  @override
  Widget build(BuildContext context) {
    final cs = Theme.of(context).colorScheme;
    final all = [(false, Str.t(context, 'ai_hello')), ...msgs];
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: const Text('AURA AI')),
      body: Column(children: [
        Expanded(
          child: ListView(padding: const EdgeInsets.all(12), children: [
            for (final (me, text) in all)
              Align(
                alignment: me ? AlignmentDirectional.centerEnd : AlignmentDirectional.centerStart,
                child: Container(
                  margin: const EdgeInsets.symmetric(vertical: 3),
                  padding: const EdgeInsets.symmetric(horizontal: 13, vertical: 9),
                  constraints: BoxConstraints(maxWidth: MediaQuery.of(context).size.width * .8),
                  decoration: BoxDecoration(color: me ? cs.primary : cs.surfaceContainerHighest, borderRadius: BorderRadius.circular(16)),
                  child: Text(text, style: TextStyle(color: me ? cs.onPrimary : null)),
                ),
              ),
          ]),
        ),
        Padding(
          padding: const EdgeInsets.symmetric(horizontal: 12),
          child: Wrap(spacing: 8, children: [
            for (final k in ['c1', 'c2', 'c3']) ActionChip(label: Text(Str.t(context, k)), onPressed: () => _ask(k)),
          ]),
        ),
        SafeArea(
          child: Padding(
            padding: const EdgeInsets.all(8),
            child: Row(children: [
              Expanded(child: TextField(controller: ctrl, onSubmitted: (v) => _ask(null, v),
                  decoration: InputDecoration(hintText: Str.t(context, 'aiph'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(24)))))),
              IconButton(icon: const Icon(Icons.send), onPressed: () => _ask(null, ctrl.text)),
            ]),
          ),
        ),
      ]),
    );
  }
}
