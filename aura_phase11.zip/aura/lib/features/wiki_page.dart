import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import '../core/strings.dart';
import '../core/wiki_data.dart';

class WikiPage extends StatefulWidget {
  const WikiPage({super.key});
  @override
  State<WikiPage> createState() => _WikiState();
}

class _WikiState extends State<WikiPage> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final i = Localizations.localeOf(context).languageCode == 'ar' ? 0 : 1;
    final items = kWiki.where((w) => q.trim().isEmpty || w.join(' ').toLowerCase().contains(q.toLowerCase().trim())).toList();
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(Str.t(context, 'wiki'))),
      body: ListView(padding: const EdgeInsets.all(12), children: [
        TextField(
          decoration: InputDecoration(hintText: i == 0 ? 'ابحث في الموسوعة' : 'Search the encyclopedia', border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)))),
          onChanged: (v) => setState(() => q = v),
        ),
        const SizedBox(height: 8),
        for (final w in items)
          Card(child: ExpansionTile(title: Text(w[i], style: const TextStyle(fontWeight: FontWeight.bold)), childrenPadding: const EdgeInsets.fromLTRB(16, 0, 16, 12), expandedCrossAxisAlignment: CrossAxisAlignment.start, children: [Text(w[i + 2])])),
        if (items.isEmpty) Padding(padding: const EdgeInsets.all(32), child: Center(child: Text(i == 0 ? 'لا نتائج' : 'No results'))),
        Padding(padding: const EdgeInsets.all(8), child: Text(i == 0 ? 'محتوى مدمج يعمل دون إنترنت (12 مقالة تجريبية).' : 'Built-in offline content (12 sample articles).', style: const TextStyle(fontSize: 12))),
      ]),
    );
  }
}
