import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/settings.dart';
import '../core/strings.dart';

class SettingsPage extends StatelessWidget {
  const SettingsPage({super.key});
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    String t(String k) => Str.t(context, k);
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(t('settings'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(t('theme')),
        const SizedBox(height: 8),
        SegmentedButton<ThemeMode>(
          selected: {s.themeMode},
          onSelectionChanged: (v) => s.setTheme(v.first),
          segments: [
            ButtonSegment(value: ThemeMode.light, label: Text(t('light'))),
            ButtonSegment(value: ThemeMode.dark, label: Text(t('dark'))),
            ButtonSegment(value: ThemeMode.system, label: Text(t('system'))),
          ],
        ),
        const SizedBox(height: 24),
        Text(t('lang')),
        const SizedBox(height: 8),
        SegmentedButton<String>(
          selected: {s.locale.languageCode},
          onSelectionChanged: (v) => s.setLang(v.first),
          segments: const [
            ButtonSegment(value: 'ar', label: Text('العربية')),
            ButtonSegment(value: 'en', label: Text('English')),
          ],
        ),
      ]),
    );
  }
}
