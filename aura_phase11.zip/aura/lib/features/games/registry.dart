import 'package:flutter/material.dart';
import 'game_impl.dart';
import 'game_impl2.dart';

class GameInfo {
  const GameInfo(this.id, this.icon, this.cat, this.players, this.names, this.rules);
  final String id, icon, cat;
  final int players;
  final List<String> names, rules; // [عربي، English]
  bool get built => kBuilders.containsKey(id);
}

const kCats = {
  'smart': ['ذكاء', 'Intelligence'], 'puzzle': ['ألغاز', 'Puzzles'], 'speed': ['سرعة', 'Speed'],
  'strategy': ['استراتيجية', 'Strategy'], 'duel': ['تنافسية ثنائية', '2-player duel'], 'detective': ['تحقيق وغموض', 'Detective'],
};

const kGames = <GameInfo>[
  GameInfo('det', '🕵️', 'detective', 1, ['قضية الماسة المفقودة', 'The Missing Gem'], ['قضية كاملة: افحص الأدلة، اقرأ أقوال المشتبهين، قارن الأوقات واتهم الفاعل. تحتاج فحص 4 أدلة على الأقل قبل الاتهام.', 'A full case: examine evidence, read suspects\' statements, compare times and accuse the culprit. Examine at least 4 clues before accusing.']),
  GameInfo('xo', '⭕', 'duel', 2, ['إكس أو', 'Tic-Tac-Toe'], ['لاعبان بالتناوب على جهاز واحد. أول من يضع ثلاث علامات في صف أو عمود أو قطر يفوز.', 'Two players alternate. First to get 3 in a row, column or diagonal wins.']),
  GameInfo('c4', '🔴', 'duel', 2, ['أربعة في صف', 'Connect Four'], ['اضغط عموداً لإسقاط قطعتك. أول من يكوّن 4 قطع متصلة أفقياً أو رأسياً أو قطرياً يفوز.', 'Tap a column to drop a disc. First to connect 4 horizontally, vertically or diagonally wins.']),
  GameInfo('rps', '✌️', 'duel', 2, ['حجر ورقة مقص', 'Rock Paper Scissors'], ['اللاعب 1 يختار ثم يمرر الجهاز للاعب 2. الحجر يكسر المقص، المقص يقص الورقة، الورقة تغطي الحجر.', 'P1 picks, then hands the device to P2. Rock beats scissors, scissors beat paper, paper beats rock.']),
  GameInfo('mem', '🃏', 'duel', 2, ['ذاكرة البطاقات', 'Memory Match'], ['اقلب بطاقتين. إن تطابقتا تأخذ نقطة وتلعب ثانية، وإلا ينتقل الدور. الأكثر نقاطاً يفوز.', 'Flip two cards. A match scores and keeps your turn; otherwise turn passes. Most pairs wins.']),
  GameInfo('react', '⚡', 'speed', 2, ['مبارزة الأعصاب', 'Reaction Duel'], ['انتظر حتى يصير اللون أخضر ثم اضغط منطقتك. من يضغط قبل الأخضر يخسر.', 'Wait for green, then tap your zone first. Tapping early loses.']),
  GameInfo('num', '🔢', 'smart', 2, ['الرقم السري', 'Secret Number'], ['اللاعب 1 يختار رقماً سرياً من 1 إلى 100، واللاعب 2 يخمّنه بمساعدة «أكبر/أصغر» بأقل عدد محاولات.', 'P1 picks a secret 1-100; P2 guesses with higher/lower hints in as few tries as possible.']),
  GameInfo('nim', '🪵', 'strategy', 2, ['لعبة العيدان (نيم)', 'Nim Sticks'], ['15 عوداً. كل لاعب يأخذ 1 إلى 3 أعواد بالتناوب. من يأخذ آخر عود يفوز.', '15 sticks. Take 1-3 per turn. Whoever takes the last stick wins.']),
  GameInfo('lights', '💡', 'puzzle', 1, ['أطفئ الأضواء', 'Lights Out'], ['الضغط على مربع يقلب حالته وحالة جيرانه. أطفئ كل المربعات بأقل عدد حركات.', 'Tapping a cell flips it and its neighbors. Turn all cells off in the fewest moves.']),
  GameInfo('slide', '🧩', 'puzzle', 1, ['أحجية الأرقام', 'Sliding Puzzle'], ['حرّك المربعات إلى الخانة الفارغة لترتيب الأرقام من 1 إلى 8.', 'Slide tiles into the gap to order the numbers 1 to 8.']),
  GameInfo('math', '➗', 'speed', 1, ['حساب سريع', 'Quick Math'], ['30 ثانية: حلّ أكبر عدد من العمليات. الجواب الصحيح +1 والخطأ -1.', '30 seconds: solve as many as you can. +1 correct, -1 wrong.']),
  GameInfo('whack', '⭐', 'speed', 1, ['اصطد النجمة', 'Catch the Star'], ['20 ثانية: اضغط النجمة قبل أن تختفي. كل إصابة نقطة.', '20 seconds: tap the star before it vanishes. One point per hit.']),
  GameInfo('simon', '🎵', 'smart', 1, ['تذكّر التسلسل', 'Simon Says'], ['شاهد تسلسل الألوان ثم كرّره. يطول التسلسل كل جولة. خطأ واحد ينهي اللعبة.', 'Watch the color sequence, then repeat it. It grows each round. One mistake ends the game.']),
  GameInfo('mm', '🎯', 'smart', 1, ['كسر الشيفرة', 'Code Breaker'], ['خمّن شيفرة من 4 ألوان خلال 8 محاولات. ⚫ لون صحيح بمكانه، ⚪ لون صحيح بمكان خاطئ.', 'Guess a 4-color code in 8 tries. ⚫ right color & place, ⚪ right color wrong place.']),
  GameInfo('hang', '🔤', 'strategy', 2, ['المشنقة', 'Hangman'], ['اللاعب 1 يكتب كلمة سرية، واللاعب 2 يخمّن الحروف. 6 أخطاء وتنتهي المحاولات.', 'P1 types a secret word; P2 guesses letters. 6 mistakes and it\'s over.']),
  GameInfo('tug', '🪢', 'speed', 2, ['شدّ الحبل', 'Tug of War'], ['كل لاعب يضغط منطقته بأسرع ما يمكن لسحب العلامة نحو جهته. من يوصلها للنهاية يفوز.', 'Each player taps their zone as fast as possible to pull the marker. Reach your end to win.']),
  GameInfo('scr', '🔀', 'puzzle', 1, ['رتّب الحروف', 'Word Scramble'], ['رتّب الحروف المبعثرة لتكوّن كلمة صحيحة. كل كلمة صحيحة نقطة.', 'Unscramble the letters into a word. One point per correct word.']),
  GameInfo('dots', '▦', 'strategy', 2, ['النقاط والمربعات', 'Dots & Boxes'], ['اضغط خطاً بين نقطتين. من يُكمل مربعاً يأخذه ويلعب ثانية. الأكثر مربعات يفوز.', 'Tap a line between dots. Completing a box claims it and gives another turn. Most boxes wins.']),
  GameInfo('pong', '🏓', 'duel', 2, ['بينغ بونغ', 'Pong'], ['اللاعب 1 يحرّك المضرب العلوي بإصبعه في النصف العلوي، واللاعب 2 السفلي. أول من يسجّل 5 يفوز.', 'P1 drags the top paddle in the top half; P2 the bottom. First to 5 wins.']),
  GameInfo('odd', '🔍', 'smart', 1, ['اعثر على المختلف', 'Find the Odd One'], ['20 ثانية: اعثر على الرمز المختلف في الشبكة. الخطأ يخصم ثانيتين.', '20 seconds: find the different symbol. A mistake costs 2 seconds.']),
];

final Map<String, Widget Function()> kBuilders = {
  'xo': () => const XoGame(),
  'c4': () => const C4Game(),
  'rps': () => const RpsGame(),
  'mem': () => const MemoryGame(),
  'nim': () => const NimGame(),
  'lights': () => const LightsGame(),
  'slide': () => const SlideGame(),
  'det': () => const DetectiveGame(),
  'react': () => const ReactGame(),
  'num': () => const NumGame(),
  'math': () => const MathGame(),
  'whack': () => const WhackGame(),
  'simon': () => const SimonGame(),
  'mm': () => const MastermindGame(),
  'hang': () => const HangGame(),
  'tug': () => const TugGame(),
  'scr': () => const ScrambleGame(),
  'dots': () => const DotsGame(),
  'pong': () => const PongGame(),
  'odd': () => const OddGame(),
};
