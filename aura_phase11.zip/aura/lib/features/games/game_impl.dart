import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'common.dart';

class XoGame extends StatefulWidget {
  const XoGame({super.key});
  @override
  State<XoGame> createState() => _XoState();
}

class _XoState extends State<XoGame> {
  List<String> b = List.filled(9, '');
  String p = 'X';
  static const lines = [[0, 1, 2], [3, 4, 5], [6, 7, 8], [0, 3, 6], [1, 4, 7], [2, 5, 8], [0, 4, 8], [2, 4, 6]];
  List<int>? win() {
    for (final l in lines) {
      if (b[l[0]].isNotEmpty && b[l[0]] == b[l[1]] && b[l[0]] == b[l[2]]) return l;
    }
    return null;
  }

  @override
  Widget build(BuildContext context) {
    final w = win();
    final full = b.every((x) => x.isNotEmpty);
    final over = w != null || full;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Status(w != null ? L(context, 'فاز ', 'Winner: ') + b[w[0]] : (full ? L(context, 'تعادل', 'Draw') : L(context, 'الدور: ', 'Turn: ') + p)),
      GridBoard(cols: 3, children: [
        for (var i = 0; i < 9; i++)
          Cell(b[i], (over || b[i].isNotEmpty) ? null : () => setState(() { b[i] = p; p = p == 'X' ? 'O' : 'X'; })),
      ]),
      ResetBtn(() => setState(() { b = List.filled(9, ''); p = 'X'; })),
    ]);
  }
}

class C4Game extends StatefulWidget {
  const C4Game({super.key});
  @override
  State<C4Game> createState() => _C4State();
}

class _C4State extends State<C4Game> {
  List<List<int>> g = List.generate(6, (_) => List.filled(7, 0));
  int p = 1;
  bool done = false;
  String msg = '';

  bool win(int r, int c) {
    for (final d in const [[0, 1], [1, 0], [1, 1], [1, -1]]) {
      var n = 1;
      for (final s in const [1, -1]) {
        var y = r + d[0] * s, x = c + d[1] * s;
        while (y >= 0 && y < 6 && x >= 0 && x < 7 && g[y][x] == p) { n++; y += d[0] * s; x += d[1] * s; }
      }
      if (n >= 4) return true;
    }
    return false;
  }

  void drop(int c) {
    if (done) return;
    var r = 5;
    while (r >= 0 && g[r][c] != 0) { r--; }
    if (r < 0) return;
    setState(() {
      g[r][c] = p;
      if (win(r, c)) {
        done = true;
        msg = L(context, 'فاز اللاعب $p', 'Player $p wins');
      } else if (g.every((row) => row.every((x) => x != 0))) {
        done = true;
        msg = L(context, 'تعادل', 'Draw');
      } else {
        p = 3 - p;
      }
    });
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(msg.isNotEmpty ? msg : L(context, 'دور اللاعب $p', 'Player $p')),
        GridBoard(cols: 7, children: [
          for (var r = 0; r < 6; r++)
            for (var c = 0; c < 7; c++)
              Cell('', () => drop(c), circle: true,
                  color: g[r][c] == 1 ? const Color(0xFF2F6BFF) : (g[r][c] == 2 ? const Color(0xFF7B3FE4) : null)),
        ]),
        ResetBtn(() => setState(() { g = List.generate(6, (_) => List.filled(7, 0)); p = 1; done = false; msg = ''; })),
      ]);
}

class RpsGame extends StatefulWidget {
  const RpsGame({super.key});
  @override
  State<RpsGame> createState() => _RpsState();
}

class _RpsState extends State<RpsGame> {
  static const o = ['✊', '✋', '✌️'];
  bool second = false;
  int a = 0;
  List<int> s = [0, 0];
  String res = '';
  void pick(int i) => setState(() {
        if (!second) { a = i; second = true; return; }
        final d = (i - a + 3) % 3;
        String r;
        if (d == 0) { r = L(context, 'تعادل', 'Draw'); }
        else if (d == 1) { s[1]++; r = L(context, 'فاز اللاعب 2', 'P2 wins'); }
        else { s[0]++; r = L(context, 'فاز اللاعب 1', 'P1 wins'); }
        res = '${o[a]} ⚔ ${o[i]} — $r';
        second = false;
      });
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        if (res.isNotEmpty) Status(res),
        Status(L(context, 'اللاعب ${second ? 2 : 1} يختار', 'Player ${second ? 2 : 1} picks')),
        Row(children: [for (var i = 0; i < 3; i++) Padding(padding: const EdgeInsetsDirectional.only(end: 8), child: SizedBox(width: 80, height: 80, child: Cell(o[i], () => pick(i), size: 32)))]),
        Padding(padding: const EdgeInsets.only(top: 8), child: Text('${s[0]} : ${s[1]}')),
      ]);
}

class MemoryGame extends StatefulWidget {
  const MemoryGame({super.key});
  @override
  State<MemoryGame> createState() => _MemState();
}

class _MemState extends State<MemoryGame> {
  static const e = ['🌌', '🚀', '🎨', '🎧', '📸', '🌠'];
  late List<String> d;
  List<int> op = [];
  Set<int> fnd = {};
  int p = 0;
  List<int> s = [0, 0];
  bool lock = false;
  Timer? t;
  @override
  void initState() { super.initState(); _new(); }
  void _new() { d = ([...e, ...e])..shuffle(); op = []; fnd = {}; p = 0; s = [0, 0]; lock = false; }
  @override
  void dispose() { t?.cancel(); super.dispose(); }
  void tap(int i) {
    if (lock || op.contains(i) || fnd.contains(i)) return;
    setState(() => op.add(i));
    if (op.length == 2) {
      lock = true;
      t = Timer(const Duration(milliseconds: 700), () {
        if (!mounted) return;
        setState(() {
          if (d[op[0]] == d[op[1]]) { fnd.addAll(op); s[p]++; } else { p = 1 - p; }
          op = [];
          lock = false;
        });
      });
    }
  }

  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status('${fnd.length == 12 ? (s[0] == s[1] ? L(context, 'تعادل', 'Draw') : L(context, 'فاز اللاعب ${s[0] > s[1] ? 1 : 2}', 'Player ${s[0] > s[1] ? 1 : 2} wins')) : L(context, 'دور اللاعب ${p + 1}', 'Player ${p + 1}')} — ${s[0]} : ${s[1]}'),
        GridBoard(cols: 4, children: [for (var i = 0; i < 12; i++) Cell((fnd.contains(i) || op.contains(i)) ? d[i] : '✦', () => tap(i))]),
        ResetBtn(() => setState(_new)),
      ]);
}

class NimGame extends StatefulWidget {
  const NimGame({super.key});
  @override
  State<NimGame> createState() => _NimState();
}

class _NimState extends State<NimGame> {
  int n = 15, p = 1;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(n == 0 ? '🏆 ${L(context, 'فاز اللاعب ${3 - p}', 'Player ${3 - p} wins')}' : L(context, 'اللاعب $p — $n عوداً', 'Player $p — $n sticks')),
        Text('|' * n, style: const TextStyle(fontSize: 26, letterSpacing: 4)),
        const SizedBox(height: 10),
        Row(children: [for (final k in [1, 2, 3]) if (k <= n) Padding(padding: const EdgeInsetsDirectional.only(end: 8), child: FilledButton(onPressed: () => setState(() { n -= k; p = 3 - p; }), child: Text('$k')))]),
        ResetBtn(() => setState(() { n = 15; p = 1; })),
      ]);
}

class LightsGame extends StatefulWidget {
  const LightsGame({super.key});
  @override
  State<LightsGame> createState() => _LightsState();
}

class _LightsState extends State<LightsGame> {
  late List<int> g;
  int mv = 0;
  final rnd = Random();
  @override
  void initState() { super.initState(); _new(); }
  void _tog(int i) {
    final r = i ~/ 5, c = i % 5;
    for (final d in const [[0, 0], [1, 0], [-1, 0], [0, 1], [0, -1]]) {
      final y = r + d[0], x = c + d[1];
      if (y >= 0 && y < 5 && x >= 0 && x < 5) g[y * 5 + x] ^= 1;
    }
  }
  void _new() { g = List.filled(25, 0); mv = 0; for (var i = 0; i < 14; i++) { _tog(rnd.nextInt(25)); } if (g.every((x) => x == 0)) _tog(12); }
  @override
  Widget build(BuildContext context) {
    final w = g.every((x) => x == 0);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Status(w ? '🎉 ${L(context, 'أطفأتها كلها بـ $mv حركة', 'All off in $mv moves')}' : L(context, 'الحركات: $mv', 'Moves: $mv')),
      GridBoard(cols: 5, children: [for (var i = 0; i < 25; i++) Cell('', w ? null : () => setState(() { _tog(i); mv++; }), color: g[i] == 1 ? const Color(0xFFFFD45E) : null)]),
      ResetBtn(() => setState(_new)),
    ]);
  }
}

class SlideGame extends StatefulWidget {
  const SlideGame({super.key});
  @override
  State<SlideGame> createState() => _SlideState();
}

class _SlideState extends State<SlideGame> {
  late List<int> t;
  int e = 8, mv = 0;
  final rnd = Random();
  List<int> nb(int k) {
    final r = k ~/ 3, c = k % 3;
    return [
      if (r > 0) k - 3, if (r < 2) k + 3, if (c > 0) k - 1, if (c < 2) k + 1,
    ];
  }
  @override
  void initState() { super.initState(); _new(); }
  void _new() {
    t = [1, 2, 3, 4, 5, 6, 7, 8, 0]; e = 8; mv = 0;
    for (var k = 0; k < 120; k++) { final o = nb(e); final j = o[rnd.nextInt(o.length)]; final tmp = t[e]; t[e] = t[j]; t[j] = tmp; e = j; }
  }
  @override
  Widget build(BuildContext context) {
    final w = List.generate(9, (i) => t[i] == (i + 1) % 9).every((x) => x);
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Status(w ? '🎉 ${L(context, 'حللتها بـ $mv حركة', 'Solved in $mv moves')}' : L(context, 'الحركات: $mv', 'Moves: $mv')),
      GridBoard(cols: 3, children: [
        for (var i = 0; i < 9; i++)
          t[i] == 0 ? const SizedBox() : Cell('${t[i]}', (w || !nb(e).contains(i)) ? null : () => setState(() { t[e] = t[i]; t[i] = 0; e = i; mv++; })),
      ]),
      ResetBtn(() => setState(_new)),
    ]);
  }
}

class DetectiveGame extends StatefulWidget {
  const DetectiveGame({super.key});
  @override
  State<DetectiveGame> createState() => _DetState();
}

class _DetState extends State<DetectiveGame> {
  int tab = 0;
  final Set<int> seen = {};
  String res = '';

  @override
  Widget build(BuildContext context) {
    String l(String a, String e) => L(context, a, e);
    final ev = <(String, String, String)>[
      ('🔍', l('مسرح الجريمة', 'Crime scene'), l('خزانة العرض فُتحت ببطاقة موظف، ولا كسر في الزجاج. وُجدت بصمة حذاء مقاس 44 قرب الخزانة.', 'The case was opened with a staff key card, no broken glass. A size-44 shoe print was found beside it.')),
      ('💳', l('سجل البطاقات', 'Card log'), l('فُتحت الخزانة ببطاقة موظف الساعة 9:35 مساءً. الزوّار لا يملكون بطاقات.', 'A staff card opened the case at 9:35 pm. Visitors hold no cards.')),
      ('📹', l('كاميرا المخرج', 'Exit camera'), l('ليلى (المصوّرة) خرجت من المتحف الساعة 9:05 ولم تعد.', 'Layla (the photographer) left the museum at 9:05 and never returned.')),
      ('☕', l('إيصال المقصف', 'Cafeteria receipt'), l('مازن (الحارس) اشترى شاياً الساعة 9:36 من المقصف البعيد عن قاعة العرض.', 'Mazen (the guard) bought tea at 9:36 at the cafeteria, far from the hall.')),
      ('🧹', l('سجل عربة التنظيف', 'Cleaning cart log'), l('عربة هدى (عاملة النظافة) سُجّلت في الجناح الشرقي الساعة 9:34 و9:41 بنشاط متواصل.', "Huda's (cleaner) cart was logged in the east wing at 9:34 and 9:41, continuously active.")),
      ('💻', l('حاسوب الأمين', "Curator's computer"), l('حاسوب سليم (الأمين) بلا أي نشاط من 9:20 إلى 9:50، رغم قوله إنه يراجع الجرد.', "Salim's (curator) computer shows no activity from 9:20 to 9:50, though he says he was reviewing inventory.")),
      ('👟', l('مقاسات الأحذية', 'Shoe sizes'), l('سليم 44، مازن 45، هدى 38، ليلى 37.', 'Salim 44, Mazen 45, Huda 38, Layla 37.')),
    ];
    final su = <(String, String, String)>[
      ('🧔', l('سليم (الأمين)', 'Salim (curator)'), l('«كنت في مكتبي أراجع الجرد طوال المساء.»', '“I was in my office reviewing inventory all evening.”')),
      ('💂', l('مازن (الحارس)', 'Mazen (guard)'), l('«كنت أحرس البوابة وخرجت لحظات لشراء شاي.»', '“I guarded the gate and stepped out briefly for tea.”')),
      ('🧹', l('هدى (عاملة النظافة)', 'Huda (cleaner)'), l('«كنت أنظف الجناح الشرقي طوال الوقت.»', '“I was cleaning the east wing the whole time.”')),
      ('📸', l('ليلى (المصوّرة)', 'Layla (photographer)'), l('«صوّرت المعرض وغادرت مبكراً.»', '“I shot photos of the exhibit and left early.”')),
    ];
    final wrong = [
      '',
      l('ليس مازن: إيصال المقصف يثبت أنه كان بعيداً، ومقاس حذائه 45 لا يطابق البصمة.', 'Not Mazen: the receipt places him far away, and his size 45 does not match the print.'),
      l('ليست هدى: سجل العربة يثبت نشاطها بالجناح الشرقي ومقاس حذائها 38.', 'Not Huda: the cart log puts her in the east wing and her shoe is size 38.'),
      l('ليست ليلى: خرجت 9:05 ولا تملك بطاقة موظف.', 'Not Layla: she left at 9:05 and holds no staff card.'),
    ];
    Widget card(String icon, String title, String? text, {VoidCallback? onTap}) => Card(
          margin: const EdgeInsets.symmetric(vertical: 4),
          child: ListTile(
            onTap: onTap, leading: Text(icon, style: const TextStyle(fontSize: 24)), title: Text(title),
            subtitle: text == null ? null : Text(text),
          ),
        );
    final tabs = [l('الأدلة', 'Evidence'), l('المشتبهون', 'Suspects'), l('ملاحظاتي', 'Notes'), l('اتهام', 'Accuse')];
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Text(l('ليلة معرض «نجمة أورا»: اختفت الماسة الزرقاء من خزانتها الساعة 9:35 مساءً. أربعة أشخاص كانوا في المتحف. افحص الأدلة، استجوب المشتبهين، قارن الأوقات ثم اتهم الفاعل.',
          'Night of the “Aura Star” exhibit: the blue gem vanished from its case at 9:35 pm. Four people were in the museum. Examine clues, read statements, compare times, then accuse the culprit.')),
      const SizedBox(height: 8),
      Wrap(spacing: 8, children: [for (var i = 0; i < 4; i++) ChoiceChip(label: Text(tabs[i]), selected: tab == i, onSelected: (_) => setState(() => tab = i))]),
      const SizedBox(height: 8),
      if (tab == 0) for (var i = 0; i < ev.length; i++) card(ev[i].$1, ev[i].$2, seen.contains(i) ? ev[i].$3 : null, onTap: () => setState(() => seen.add(i))),
      if (tab == 1) for (final s in su) card(s.$1, s.$2, s.$3),
      if (tab == 2) ...(seen.isEmpty ? [Text(l('لم تفحص أي دليل بعد.', 'No clues examined yet.'))] : [for (final i in (seen.toList()..sort())) card(ev[i].$1, ev[i].$2, ev[i].$3)]),
      if (tab == 3) ...[
        Text(l('مَن الفاعل؟ (تحتاج فحص 4 أدلة على الأقل)', 'Who did it? (examine at least 4 clues first)')),
        for (var i = 0; i < 4; i++)
          card(su[i].$1, su[i].$2, null, onTap: () => setState(() {
                if (seen.length < 4) { res = l('ما زالت الأدلة غير كافية. افحص المزيد.', 'Not enough evidence yet. Examine more clues.'); }
                else if (i == 0) { res = l('🎉 صحيح! الفاعل هو سليم: البطاقة المستخدمة 9:35 لموظف، ومقاس حذائه 44 يطابق البصمة، وحاسوبه بلا نشاط (يكذب بشأن مراجعة الجرد). مازن في المقصف 9:36، وهدى نشطة في الجناح الشرقي، وليلى خرجت 9:05 بلا بطاقة.', '🎉 Correct! Salim did it: a staff card opened the case at 9:35, his size-44 shoe matches the print, and his computer was idle (he lied about the inventory). Mazen was at the cafeteria at 9:36, Huda was active in the east wing and Layla left at 9:05 with no card.'); }
                else { res = wrong[i]; }
              })),
        if (res.isNotEmpty) Padding(padding: const EdgeInsets.only(top: 10), child: Text(res, style: const TextStyle(fontWeight: FontWeight.bold))),
      ],
    ]);
  }
}
