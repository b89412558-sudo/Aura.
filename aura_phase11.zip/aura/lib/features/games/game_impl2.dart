import 'dart:async';
import 'dart:math';
import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../../core/state.dart';
import 'common.dart';

final _rnd = Random();
int _best(BuildContext c, String id, int v, {bool low = false}) => c.read<AppState>().bestOf(id, v, low: low);

/// مبارزة الأعصاب
class ReactGame extends StatefulWidget {
  const ReactGame({super.key});
  @override
  State<ReactGame> createState() => _ReactState();
}

class _ReactState extends State<ReactGame> {
  bool go = false, done = false;
  int winner = 0, t0 = 0;
  String why = '';
  Timer? t;
  @override
  void initState() { super.initState(); _start(); }
  void _start() {
    t?.cancel();
    go = false; done = false; winner = 0; why = '';
    t = Timer(Duration(milliseconds: 1500 + _rnd.nextInt(2500)), () {
      if (mounted) setState(() { go = true; t0 = DateTime.now().millisecondsSinceEpoch; });
    });
  }
  @override
  void dispose() { t?.cancel(); super.dispose(); }
  void tap(int n) {
    if (done) return;
    setState(() {
      done = true;
      if (!go) { winner = 3 - n; why = 'early'; } else { winner = n; why = '${DateTime.now().millisecondsSinceEpoch - t0} ms'; }
    });
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(done
            ? L(context, 'فاز اللاعب $winner — ${why == 'early' ? 'الآخر ضغط مبكراً' : why}', 'Player $winner — ${why == 'early' ? 'the other tapped early' : why}')
            : L(context, 'انتظر اللون الأخضر ثم اضغط منطقتك!', 'Wait for green, then tap your zone!')),
        Row(children: [
          for (final n in [1, 2])
            Expanded(child: Padding(padding: const EdgeInsets.all(4), child: SizedBox(height: 120, child: Cell('$n', () => tap(n), size: 34, color: (go && !done) ? const Color(0xFF1FBF6B) : null)))),
        ]),
        ResetBtn(() => setState(_start)),
      ]);
}

/// الرقم السري
class NumGame extends StatefulWidget {
  const NumGame({super.key});
  @override
  State<NumGame> createState() => _NumState();
}

class _NumState extends State<NumGame> {
  int stage = 0, sec = 0, n = 0;
  String hint = '';
  final c = TextEditingController();
  @override
  void dispose() { c.dispose(); super.dispose(); }
  void ok() {
    final v = int.tryParse(c.text.trim());
    if (v == null) return;
    setState(() {
      if (stage == 0) { if (v >= 1 && v <= 100) { sec = v; n = 0; stage = 1; hint = ''; } }
      else {
        n++;
        if (v == sec) { stage = 2; } else { hint = v < sec ? L(context, '↑ أكبر', '↑ higher') : L(context, '↓ أصغر', '↓ lower'); }
      }
    });
    c.clear();
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(stage == 0 ? L(context, 'اللاعب 1: اكتب رقماً سرياً (1-100)', 'P1: enter a secret number (1-100)')
            : stage == 1 ? '${L(context, 'اللاعب 2: خمّن الرقم', 'P2: guess the number')} $hint — ${L(context, 'المحاولات', 'Tries')}: $n'
            : '🎉 ${L(context, 'صحيح بعد $n محاولة', 'Correct after $n tries')}'),
        if (stage < 2) Row(children: [
          Expanded(child: TextField(controller: c, obscureText: stage == 0, keyboardType: TextInputType.number, onSubmitted: (_) => ok())),
          const SizedBox(width: 8),
          FilledButton(onPressed: ok, child: const Text('OK')),
        ]),
        ResetBtn(() => setState(() { stage = 0; n = 0; hint = ''; c.clear(); })),
      ]);
}

/// حساب سريع
class MathGame extends StatefulWidget {
  const MathGame({super.key});
  @override
  State<MathGame> createState() => _MathState();
}

class _MathState extends State<MathGame> {
  int s = 0, tl = 30, a = 0, b = 0, ans = 0, bestV = 0;
  String op = '+';
  bool over = false;
  Timer? t;
  final c = TextEditingController();
  @override
  void initState() { super.initState(); _start(); }
  void _nq() {
    a = _rnd.nextInt(12) + 2; b = _rnd.nextInt(12) + 2;
    final k = _rnd.nextInt(3);
    op = ['+', '-', '×'][k];
    ans = k == 0 ? a + b : (k == 1 ? a - b : a * b);
  }
  void _start() {
    t?.cancel(); s = 0; tl = 30; over = false; _nq(); c.clear();
    t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        tl--;
        if (tl <= 0) { over = true; t?.cancel(); bestV = _best(context, 'math', s); }
      });
    });
  }
  @override
  void dispose() { t?.cancel(); c.dispose(); super.dispose(); }
  void submit() {
    if (over) return;
    final v = int.tryParse(c.text.trim());
    if (v == null) return;
    setState(() { if (v == ans) { s++; } else { s = max(0, s - 1); } _nq(); });
    c.clear();
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(over ? L(context, 'انتهى الوقت! نقاطك $s — الأفضل $bestV', 'Time up! Score $s — Best $bestV') : '⏱ $tl — $s'),
        if (!over) ...[
          Center(child: Text('$a $op $b = ?', style: const TextStyle(fontSize: 30))),
          Row(children: [
            Expanded(child: TextField(controller: c, autofocus: true, keyboardType: const TextInputType.numberWithOptions(signed: true), onSubmitted: (_) => submit())),
            const SizedBox(width: 8),
            FilledButton(onPressed: submit, child: const Text('OK')),
          ]),
        ],
        ResetBtn(() => setState(_start)),
      ]);
}

/// اصطد النجمة
class WhackGame extends StatefulWidget {
  const WhackGame({super.key});
  @override
  State<WhackGame> createState() => _WhackState();
}

class _WhackState extends State<WhackGame> {
  int s = 0, tl = 20, pos = -1, bestV = 0;
  bool over = false;
  Timer? t1, t2;
  @override
  void initState() { super.initState(); _start(); }
  void _start() {
    t1?.cancel(); t2?.cancel(); s = 0; tl = 20; pos = -1; over = false;
    t1 = Timer.periodic(const Duration(milliseconds: 800), (_) { if (mounted && !over) setState(() => pos = _rnd.nextInt(9)); });
    t2 = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() {
        tl--;
        if (tl <= 0) { over = true; t1?.cancel(); t2?.cancel(); bestV = _best(context, 'whack', s); }
      });
    });
  }
  @override
  void dispose() { t1?.cancel(); t2?.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(over ? L(context, 'انتهى الوقت! نقاطك $s — الأفضل $bestV', 'Time up! Score $s — Best $bestV') : '⏱ $tl — $s'),
        GridBoard(cols: 3, children: [for (var i = 0; i < 9; i++) Cell(i == pos ? '⭐' : '', over ? null : () { if (i == pos) setState(() { s++; pos = -1; }); })]),
        ResetBtn(() => setState(_start)),
      ]);
}

/// تذكّر التسلسل
class SimonGame extends StatefulWidget {
  const SimonGame({super.key});
  @override
  State<SimonGame> createState() => _SimonState();
}

class _SimonState extends State<SimonGame> {
  static const cols = [Color(0xFF2F6BFF), Color(0xFF00C8E0), Color(0xFF7B3FE4), Color(0xFFE0A800)];
  List<int> seq = [];
  int i = 0, lit = -1, bestV = 0;
  bool show = false, dead = false;
  final List<Timer> ts = [];
  @override
  void initState() { super.initState(); _next(); }
  void _later(int ms, VoidCallback f) { ts.add(Timer(Duration(milliseconds: ms), () { if (mounted) f(); })); }
  void _flash(int k) { setState(() => lit = k); _later(300, () => setState(() => lit = -1)); }
  void _next() {
    seq.add(_rnd.nextInt(4)); i = 0; show = true;
    for (var n = 0; n < seq.length; n++) { final k = seq[n]; _later(600 * (n + 1), () => _flash(k)); }
    _later(600 * seq.length + 300, () => setState(() => show = false));
  }
  void _reset() { for (final t in ts) { t.cancel(); } ts.clear(); seq = []; dead = false; lit = -1; _next(); }
  @override
  void dispose() { for (final t in ts) { t.cancel(); } super.dispose(); }
  void tap(int k) {
    if (show || dead) return;
    _flash(k);
    if (k != seq[i]) { setState(() { dead = true; bestV = _best(context, 'simon', seq.length - 1); }); return; }
    i++;
    if (i == seq.length) { show = true; _later(700, _next); }
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(dead ? L(context, 'خسرت! مستواك ${seq.length - 1} — الأفضل $bestV', 'Lost! Level ${seq.length - 1} — Best $bestV') : (show ? L(context, 'شاهد...', 'Watch...') : L(context, 'دورك! المستوى ${seq.length}', 'Your turn! Level ${seq.length}'))),
        GridBoard(cols: 2, max: 300, children: [for (var k = 0; k < 4; k++) Cell('', () => tap(k), color: cols[k].withOpacity(lit == k ? 1 : .5))]),
        ResetBtn(() => setState(_reset)),
      ]);
}

/// كسر الشيفرة
class MastermindGame extends StatefulWidget {
  const MastermindGame({super.key});
  @override
  State<MastermindGame> createState() => _MmState();
}

class _MmState extends State<MastermindGame> {
  static const cs = ['🔴', '🟢', '🔵', '🟡', '🟣', '🟠'];
  late List<int> sec;
  List<int> cur = [];
  List<(List<int>, int, int)> hist = [];
  int done = 0;
  @override
  void initState() { super.initState(); _new(); }
  void _new() { sec = List.generate(4, (_) => _rnd.nextInt(6)); cur = []; hist = []; done = 0; }
  (int, int) _fb(List<int> g) {
    var bl = 0, wh = 0;
    final a = <int>[], b = <int>[];
    for (var i = 0; i < 4; i++) { if (g[i] == sec[i]) { bl++; } else { a.add(g[i]); b.add(sec[i]); } }
    for (final v in a) { final k = b.indexOf(v); if (k >= 0) { wh++; b.removeAt(k); } }
    return (bl, wh);
  }
  void add(int i) {
    if (done != 0 || cur.length >= 4) return;
    setState(() {
      cur.add(i);
      if (cur.length == 4) {
        final r = _fb(cur);
        hist.add((List.of(cur), r.$1, r.$2));
        if (r.$1 == 4) { done = 1; } else if (hist.length >= 8) { done = 2; }
        cur = [];
      }
    });
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(done == 1 ? '🎉 ${L(context, 'كسرت الشيفرة!', 'Code cracked!')}' : (done == 2 ? '${L(context, 'انتهت المحاولات: ', 'Out of tries: ')}${sec.map((i) => cs[i]).join()}' : L(context, 'المحاولات المتبقية: ${8 - hist.length}', 'Tries left: ${8 - hist.length}'))),
        for (final h in hist) Text('${h.$1.map((i) => cs[i]).join()}  ⚫${h.$2} ⚪${h.$3}', style: const TextStyle(fontSize: 20)),
        Status(cur.isEmpty ? '…' : cur.map((i) => cs[i]).join()),
        Wrap(spacing: 8, children: [for (var i = 0; i < 6; i++) SizedBox(width: 50, height: 50, child: Cell(cs[i], () => add(i), size: 20, circle: true))]),
        Row(children: [IconButton(onPressed: () => setState(() { if (cur.isNotEmpty) cur.removeLast(); }), icon: const Icon(Icons.backspace_outlined)), ResetBtn(() => setState(_new))]),
      ]);
}

/// المشنقة
class HangGame extends StatefulWidget {
  const HangGame({super.key});
  @override
  State<HangGame> createState() => _HangState();
}

class _HangState extends State<HangGame> {
  String w = '';
  List<String> g = [];
  int wr = 0;
  final c = TextEditingController();
  @override
  void dispose() { c.dispose(); super.dispose(); }
  @override
  Widget build(BuildContext context) {
    final ar = Localizations.localeOf(context).languageCode == 'ar';
    final al = (ar ? 'ابتثجحخدذرزسشصضطظعغفقكلمنهوي' : 'abcdefghijklmnopqrstuvwxyz').split('');
    if (w.isEmpty) {
      return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(L(context, 'اللاعب 1: اكتب كلمة سرية', 'P1: enter a secret word')),
        Row(children: [
          Expanded(child: TextField(controller: c, obscureText: true)),
          const SizedBox(width: 8),
          FilledButton(onPressed: () { final v = c.text.trim().toLowerCase().replaceAll(' ', ''); if (v.length >= 2) { setState(() { w = v; g = []; wr = 0; }); c.clear(); } }, child: const Text('OK')),
        ]),
      ]);
    }
    final letters = w.split('');
    final won = letters.every(g.contains), lost = wr >= 6;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Status('${'❤️' * (6 - wr)}${'🖤' * wr}'),
      Center(child: Text(letters.map((x) => (g.contains(x) || lost) ? x : '_').join(' '), style: const TextStyle(fontSize: 30, letterSpacing: 2))),
      if (won) Status('🎉 ${L(context, 'فاز اللاعب 2', 'P2 wins')}'),
      if (lost) Status(L(context, 'فاز اللاعب 1', 'P1 wins')),
      Wrap(spacing: 6, runSpacing: 6, children: [
        for (final x in al)
          SizedBox(width: 40, height: 40, child: Cell(x, (g.contains(x) || won || lost) ? null : () => setState(() { g.add(x); if (!w.contains(x)) wr++; }), size: 16)),
      ]),
      ResetBtn(() => setState(() { w = ''; g = []; wr = 0; })),
    ]);
  }
}

/// شدّ الحبل
class TugGame extends StatefulWidget {
  const TugGame({super.key});
  @override
  State<TugGame> createState() => _TugState();
}

class _TugState extends State<TugGame> {
  int p = 5, done = 0;
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(done != 0 ? L(context, 'فاز اللاعب $done', 'Player $done wins') : L(context, 'اضغط بأسرع ما يمكن!', 'Tap as fast as you can!')),
        Row(children: [for (var i = 0; i < 11; i++) Expanded(child: Container(height: i == p ? 26 : 16, margin: const EdgeInsets.all(2), decoration: BoxDecoration(color: i == p ? const Color(0xFF7B3FE4) : const Color(0x2E7B3FE4), borderRadius: BorderRadius.circular(8))))]),
        const SizedBox(height: 12),
        Row(children: [
          for (final n in [1, 2])
            Expanded(child: Padding(padding: const EdgeInsets.all(4), child: SizedBox(height: 120, child: Cell('$n', done != 0 ? null : () => setState(() {
                  if (n == 1) { p--; if (p <= 0) done = 1; } else { p++; if (p >= 10) done = 2; }
                }), size: 34)))),
        ]),
        ResetBtn(() => setState(() { p = 5; done = 0; })),
      ]);
}

/// رتّب الحروف
class ScrambleGame extends StatefulWidget {
  const ScrambleGame({super.key});
  @override
  State<ScrambleGame> createState() => _ScrState();
}

class _ScrState extends State<ScrambleGame> {
  static const ar = ['مجرة', 'نجمة', 'صاروخ', 'كوكب', 'سديم', 'قمر', 'شهاب', 'فضاء'];
  static const en = ['galaxy', 'planet', 'rocket', 'nebula', 'comet', 'orbit', 'stars', 'cosmos'];
  int wi = _rnd.nextInt(8), s = 0;
  List<int> perm = [];
  String note = '';
  final c = TextEditingController();
  @override
  void dispose() { c.dispose(); super.dispose(); }
  void _shuffle(int len) {
    var k = 0;
    do { perm = List.generate(len, (i) => i)..shuffle(); k++; } while (perm.asMap().entries.every((e) => e.key == e.value) && k < 20);
  }
  void next() { wi = _rnd.nextInt(8); perm = []; }
  @override
  Widget build(BuildContext context) {
    final isAr = Localizations.localeOf(context).languageCode == 'ar';
    final w = (isAr ? ar : en)[wi].split('');
    if (perm.length != w.length) _shuffle(w.length);
    void check() {
      final v = c.text.trim().toLowerCase();
      setState(() {
        if (v == w.join()) { s++; _best(context, 'scr', s); note = '✓'; next(); } else { note = '✗'; }
      });
      c.clear();
    }
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Status('${L(context, 'النقاط', 'Score')}: $s $note'),
      Center(child: Text(perm.map((i) => w[i]).join(' '), style: const TextStyle(fontSize: 30, letterSpacing: 2))),
      Row(children: [
        Expanded(child: TextField(controller: c, onSubmitted: (_) => check())),
        const SizedBox(width: 8),
        FilledButton(onPressed: check, child: const Text('OK')),
        IconButton(onPressed: () => setState(next), icon: const Icon(Icons.skip_next)),
      ]),
    ]);
  }
}

/// النقاط والمربعات
class DotsGame extends StatefulWidget {
  const DotsGame({super.key});
  @override
  State<DotsGame> createState() => _DotsState();
}

class _DotsState extends State<DotsGame> {
  final Set<String> e = {};
  final Map<String, int> o = {};
  int p = 1;
  List<int> s = [0, 0];
  bool _box(int r, int c) => e.contains('${r - 1},$c') && e.contains('${r + 1},$c') && e.contains('$r,${c - 1}') && e.contains('$r,${c + 1}');
  void tap(int r, int c) {
    final k = '$r,$c';
    if (e.contains(k) || o.length == 9) return;
    setState(() {
      e.add(k);
      var got = false;
      for (final d in const [[-1, 0], [1, 0], [0, -1], [0, 1]]) {
        final y = r + d[0], x = c + d[1];
        if (y > 0 && y < 6 && x > 0 && x < 6 && y.isOdd && x.isOdd && !o.containsKey('$y,$x') && _box(y, x)) { o['$y,$x'] = p; s[p - 1]++; got = true; }
      }
      if (!got) p = 3 - p;
    });
  }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status('${o.length == 9 ? (s[0] == s[1] ? L(context, 'تعادل', 'Draw') : L(context, 'فاز اللاعب ${s[0] > s[1] ? 1 : 2}', 'Player ${s[0] > s[1] ? 1 : 2} wins')) : L(context, 'دور اللاعب $p', 'Player $p')} — ${s[0]} : ${s[1]}'),
        Column(children: [
          for (var r = 0; r < 7; r++)
            Row(mainAxisSize: MainAxisSize.min, children: [
              for (var c = 0; c < 7; c++)
                SizedBox(
                  width: c.isEven ? 12 : 46, height: r.isEven ? 12 : 46,
                  child: (r.isEven && c.isEven)
                      ? const DecoratedBox(decoration: BoxDecoration(color: Color(0xFF7B3FE4), shape: BoxShape.circle))
                      : ((r + c).isOdd
                          ? GestureDetector(onTap: () => tap(r, c), child: Container(margin: const EdgeInsets.all(1), color: e.contains('$r,$c') ? const Color(0xFF00C8E0) : const Color(0x2E7B3FE4)))
                          : Center(child: Text(o.containsKey('$r,$c') ? '${o['$r,$c']}' : '', style: const TextStyle(fontWeight: FontWeight.bold)))),
                ),
            ]),
        ]),
        ResetBtn(() => setState(() { e.clear(); o.clear(); p = 1; s = [0, 0]; })),
      ]);
}

/// بينغ بونغ
class PongGame extends StatefulWidget {
  const PongGame({super.key});
  @override
  State<PongGame> createState() => _PongState();
}

class _PongState extends State<PongGame> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 1))..addListener(_step)..repeat();
  double p1 = 150, p2 = 150, bx = 150, by = 210, vx = 2.4, vy = 3;
  List<int> s = [0, 0];
  @override
  void dispose() { ac.dispose(); super.dispose(); }
  void _rs() { bx = 150; by = 210; vx = (_rnd.nextBool() ? -1 : 1) * 2.4; vy = (_rnd.nextBool() ? -1 : 1) * 3; }
  void _step() {
    if (s[0] >= 5 || s[1] >= 5) return;
    bx += vx; by += vy;
    if (bx < 5 || bx > 295) vx = -vx;
    if (by < 20 && (bx - p1).abs() < 38 && vy < 0) { vy = -vy * 1.04; vx += (bx - p1) / 20; }
    if (by > 400 && (bx - p2).abs() < 38 && vy > 0) { vy = -vy * 1.04; vx += (bx - p2) / 20; }
    if (by < 0) { s[1]++; _rs(); }
    if (by > 420) { s[0]++; _rs(); }
    setState(() {});
  }
  void _move(Offset pos, Size sz) {
    final px = pos.dx * 300 / sz.width, py = pos.dy * 420 / sz.height;
    if (py < 210) { p1 = px; } else { p2 = px; }
  }
  @override
  Widget build(BuildContext context) {
    final over = s[0] >= 5 || s[1] >= 5;
    return Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
      Status(over ? L(context, 'فاز اللاعب ${s[0] >= 5 ? 1 : 2}', 'Player ${s[0] >= 5 ? 1 : 2} wins') : '${s[0]} : ${s[1]}'),
      Center(
        child: ConstrainedBox(
          constraints: const BoxConstraints(maxWidth: 300),
          child: AspectRatio(
            aspectRatio: 300 / 420,
            child: LayoutBuilder(builder: (c, box) {
              final sz = Size(box.maxWidth, box.maxHeight);
              return GestureDetector(
                onPanDown: (d) => _move(d.localPosition, sz),
                onPanUpdate: (d) => _move(d.localPosition, sz),
                child: CustomPaint(painter: _PongPainter(p1, p2, bx, by)),
              );
            }),
          ),
        ),
      ),
      ResetBtn(() => setState(() { s = [0, 0]; _rs(); })),
    ]);
  }
}

class _PongPainter extends CustomPainter {
  _PongPainter(this.p1, this.p2, this.bx, this.by);
  final double p1, p2, bx, by;
  @override
  void paint(Canvas c, Size s) {
    final k = s.width / 300;
    c.drawRRect(RRect.fromRectAndRadius(Offset.zero & s, const Radius.circular(16)), Paint()..color = const Color(0xFF0A0A1E));
    c.drawLine(Offset(0, s.height / 2), Offset(s.width, s.height / 2), Paint()..color = const Color(0x33FFFFFF));
    c.drawRect(Rect.fromLTWH((p1 - 35) * k, 8 * k, 70 * k, 8 * k), Paint()..color = const Color(0xFF7B3FE4));
    c.drawRect(Rect.fromLTWH((p2 - 35) * k, 404 * k, 70 * k, 8 * k), Paint()..color = const Color(0xFF00C8E0));
    c.drawCircle(Offset(bx * k, by * k), 7 * k, Paint()..color = Colors.white);
  }
  @override
  bool shouldRepaint(covariant _PongPainter o) => true;
}

/// اعثر على المختلف
class OddGame extends StatefulWidget {
  const OddGame({super.key});
  @override
  State<OddGame> createState() => _OddState();
}

class _OddState extends State<OddGame> {
  static const pairs = [['🌕', '🌑'], ['⭐', '✨'], ['🔵', '🟣'], ['🌸', '🌼'], ['🪐', '🌍']];
  int s = 0, tl = 20, o = 0, pi = 0, bestV = 0;
  bool over = false;
  Timer? t;
  @override
  void initState() { super.initState(); _start(); }
  void _round() { pi = _rnd.nextInt(pairs.length); o = _rnd.nextInt(25); }
  void _start() {
    t?.cancel(); s = 0; tl = 20; over = false; _round();
    t = Timer.periodic(const Duration(seconds: 1), (_) {
      if (!mounted) return;
      setState(() { tl--; if (tl <= 0) { over = true; t?.cancel(); bestV = _best(context, 'odd', s); } });
    });
  }
  @override
  void dispose() { t?.cancel(); super.dispose(); }
  @override
  Widget build(BuildContext context) => Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
        Status(over ? L(context, 'انتهى الوقت! نقاطك $s — الأفضل $bestV', 'Time up! Score $s — Best $bestV') : '⏱ $tl — $s'),
        GridBoard(cols: 5, children: [
          for (var i = 0; i < 25; i++)
            Cell(i == o ? pairs[pi][1] : pairs[pi][0], over ? null : () => setState(() {
                  if (i == o) { s++; _round(); } else { tl = max(0, tl - 2); }
                }), circle: true, size: 20),
        ]),
        ResetBtn(() => setState(_start)),
      ]);
}
