import 'package:flutter/material.dart';

String L(BuildContext c, String ar, String en) => Localizations.localeOf(c).languageCode == 'ar' ? ar : en;

class Status extends StatelessWidget {
  const Status(this.t, {super.key});
  final String t;
  @override
  Widget build(BuildContext c) =>
      Padding(padding: const EdgeInsets.symmetric(vertical: 8), child: Text(t, style: const TextStyle(fontSize: 16, fontWeight: FontWeight.bold)));
}

class Cell extends StatelessWidget {
  const Cell(this.label, this.onTap, {super.key, this.color, this.size = 26, this.circle = false});
  final String label;
  final VoidCallback? onTap;
  final Color? color;
  final double size;
  final bool circle;
  @override
  Widget build(BuildContext c) => InkWell(
        onTap: onTap,
        borderRadius: BorderRadius.circular(circle ? 100 : 14),
        child: Container(
          alignment: Alignment.center,
          decoration: BoxDecoration(
            color: color ?? Theme.of(c).cardColor,
            shape: circle ? BoxShape.circle : BoxShape.rectangle,
            borderRadius: circle ? null : BorderRadius.circular(14),
            border: Border.all(color: const Color(0x2E7B3FE4)),
          ),
          child: Text(label, style: TextStyle(fontSize: size)),
        ),
      );
}

class GridBoard extends StatelessWidget {
  const GridBoard({super.key, required this.cols, required this.children, this.max = 340});
  final int cols;
  final List<Widget> children;
  final double max;
  @override
  Widget build(BuildContext c) => Align(
        alignment: AlignmentDirectional.centerStart,
        child: ConstrainedBox(
          constraints: BoxConstraints(maxWidth: max),
          child: GridView.count(
            crossAxisCount: cols, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(),
            mainAxisSpacing: 6, crossAxisSpacing: 6, children: children),
        ),
      );
}

class ResetBtn extends StatelessWidget {
  const ResetBtn(this.onTap, {super.key});
  final VoidCallback onTap;
  @override
  Widget build(BuildContext c) => Padding(
      padding: const EdgeInsets.only(top: 10),
      child: Align(alignment: AlignmentDirectional.centerStart, child: IconButton.filled(onPressed: onTap, icon: const Icon(Icons.refresh))));
}
