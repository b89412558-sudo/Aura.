import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../../core/state.dart';
import '../../core/strings.dart';
import 'common.dart';
import 'registry.dart';

class GamesPage extends StatelessWidget {
  const GamesPage({super.key});
  @override
  Widget build(BuildContext context) {
    final ar = Localizations.localeOf(context).languageCode == 'ar' ? 0 : 1;
    final built = kGames.where((g) => g.built).length;
    final best = context.watch<AppState>().best;
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(Str.t(context, 'games'))),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Text(L(context, '20 لعبة مخططة. المبنية الآن في التطبيق: $built، والبقية قيد البناء. تعمل دون إنترنت، واللاعبان يتناوبان على الجهاز نفسه.', '20 planned games. Built in the app now: $built; the rest are in progress. They work offline; two players share one device.')),
        const SizedBox(height: 12),
        GridView.extent(
          maxCrossAxisExtent: 170, shrinkWrap: true, physics: const NeverScrollableScrollPhysics(), mainAxisSpacing: 12, crossAxisSpacing: 12,
          children: [
            for (final g in kGames)
              InkWell(
                borderRadius: BorderRadius.circular(20),
                onTap: () {
                  if (g.built) { context.push('/game/${g.id}'); }
                  else { ScaffoldMessenger.of(context).showSnackBar(SnackBar(content: Text(L(context, 'هذه اللعبة قيد البناء في التطبيق (موجودة في المعاينة).', 'This game is still being built in the app (it exists in the web preview).')))); }
                },
                child: Ink(
                  decoration: BoxDecoration(
                    borderRadius: BorderRadius.circular(20),
                    gradient: const RadialGradient(center: Alignment(0, -.3), colors: [Color(0xFF2A1D6E), Color(0xFF0A0A1E)]),
                    border: Border.all(color: const Color(0x4DC9B8FF)),
                  ),
                  child: Opacity(
                    opacity: g.built ? 1 : .5,
                    child: Column(mainAxisAlignment: MainAxisAlignment.center, children: [
                      Text(g.icon, style: const TextStyle(fontSize: 34)),
                      const SizedBox(height: 6),
                      Text(g.names[ar], textAlign: TextAlign.center, style: const TextStyle(color: Color(0xFFECEAFF))),
                      Text('${kCats[g.cat]![ar]} · 👥${g.players}${g.built ? (best[g.id] != null ? ' · ★${best[g.id]}' : '') : ' · ${L(context, 'قريباً', 'soon')}'}', style: const TextStyle(color: Color(0xCCECEAFF), fontSize: 10)),
                    ]),
                  ),
                ),
              ),
          ],
        ),
      ]),
    );
  }
}

class GamePage extends StatelessWidget {
  const GamePage({super.key, required this.id});
  final String id;
  @override
  Widget build(BuildContext context) {
    final ar = Localizations.localeOf(context).languageCode == 'ar' ? 0 : 1;
    final g = kGames.firstWhere((x) => x.id == id, orElse: () => kGames.first);
    final b = kBuilders[g.id];
    return Scaffold(
      appBar: AppBar(leading: BackButton(onPressed: () => context.pop()), title: Text(g.names[ar])),
      body: ListView(padding: const EdgeInsets.all(16), children: [
        Container(
          padding: const EdgeInsets.all(12),
          decoration: BoxDecoration(color: const Color(0x1A7B3FE4), borderRadius: BorderRadius.circular(14)),
          child: Text(g.rules[ar]),
        ),
        const SizedBox(height: 12),
        if (b != null) b() else Text(L(context, 'قيد البناء', 'In progress')),
      ]),
    );
  }
}
