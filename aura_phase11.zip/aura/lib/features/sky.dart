import 'dart:math';
import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/assets.dart';
import '../core/demo.dart';
import '../core/state.dart';
import '../core/strings.dart';

const _gal = BoxDecoration(
  gradient: RadialGradient(colors: [Color(0xFF2A1D6E), Color(0xFF14103A), Color(0xFF07071A)], stops: [0, .45, 1]),
  borderRadius: BorderRadius.all(Radius.circular(28)),
);

Widget _core() => Container(
      width: 54, height: 54,
      decoration: const BoxDecoration(shape: BoxShape.circle, boxShadow: [
        BoxShadow(color: Color(0x7300E5FF), blurRadius: 26, spreadRadius: 6),
        BoxShadow(color: Color(0x667B3FE4), blurRadius: 44, spreadRadius: 10),
      ]),
      child: Image.asset('assets/logo/aura_icon.png'),
    );

Widget _ring(double w, double h) => Center(
      child: Container(
        width: w, height: h,
        decoration: const ShapeDecoration(shape: OvalBorder(side: BorderSide(color: Color(0x47C9B8FF), width: 1))),
      ),
    );

/// سماء مجرّية: النجوم = الأصدقاء حول النواة، المدار القريب/البعيد.
class OrbitSky extends StatelessWidget {
  const OrbitSky({super.key, required this.height, required this.onTap, required this.hintKey});
  final double height;
  final void Function(int) onTap;
  final String hintKey;
  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    const rad = [[26.0, 27.0], [41.0, 40.0]];
    final by = <List<int>>[[], []];
    for (var i = 0; i < kUsers.length; i++) { by[st.orb[i]!].add(i); }
    return Container(
      height: height,
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 14),
      decoration: _gal,
      clipBehavior: Clip.antiAlias,
      child: LayoutBuilder(builder: (c, box) {
        final w = box.maxWidth, h = box.maxHeight;
        final kids = <Widget>[
          _ring(w * rad[0][0] * 2 / 100, h * rad[0][1] * 2 / 100),
          _ring(w * rad[1][0] * 2 / 100, h * rad[1][1] * 2 / 100),
          Center(child: _core()),
        ];
        for (var o = 0; o < 2; o++) {
          for (var k = 0; k < by[o].length; k++) {
            final i = by[o][k];
            final a = k / by[o].length * 2 * pi + (o == 1 ? .9 : .2);
            final x = 50 + rad[o][0] * cos(a), y = 50 + rad[o][1] * sin(a);
            final sz = o == 1 ? 34.0 : 42.0;
            final seen = st.seen.contains(i);
            kids.add(Positioned(
              left: w * x / 100 - 36, top: h * y / 100 - sz / 2 - 4, width: 72,
              child: GestureDetector(
                onTap: () => onTap(i),
                child: Opacity(
                  opacity: seen ? .6 : 1,
                  child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Container(
                      decoration: BoxDecoration(shape: BoxShape.circle,
                          border: Border.all(color: Colors.white.withOpacity(seen ? .25 : .8), width: 2),
                          boxShadow: seen ? null : const [BoxShadow(color: Color(0x8C00E5FF), blurRadius: 12, spreadRadius: 2)]),
                      child: Av(i, sz),
                    ),
                    Text(uname(context, i), style: const TextStyle(color: Color(0xFFE8E4FF), fontSize: 10)),
                  ]),
                ),
              ),
            ));
          }
        }
        kids.add(Positioned(
          left: 0, right: 0, bottom: 8,
          child: Text(Str.t(context, hintKey), textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xB3E8E4FF), fontSize: 11)),
        ));
        return Stack(children: kids);
      }),
    );
  }
}

/// كوكبة المحادثات: الأحدث أقرب للمركز، وخطوط بين أصدقاء المدار نفسه.
class Constellation extends StatelessWidget {
  const Constellation({super.key});
  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    final ord = [for (var i = 0; i < 5; i++) (i, st.chats.containsKey(i) ? 0 : kAges[i])]
      ..sort((a, b) => a.$2.compareTo(b.$2));
    final pos = <int, Offset>{};
    for (var k = 0; k < ord.length; k++) {
      final a = k * 2.4 + .4, r = 13 + k * 7.5;
      pos[ord[k].$1] = Offset(50 + r * cos(a) * .95, 50 + r * sin(a) * .95);
    }
    final lines = <(Offset, Offset)>[];
    for (final a in ord) {
      for (final b in ord) {
        if (a.$1 < b.$1 && st.orb[a.$1] == st.orb[b.$1]) { lines.add((pos[a.$1]!, pos[b.$1]!)); }
      }
    }
    return Container(
      height: 430,
      margin: const EdgeInsets.fromLTRB(12, 4, 12, 14),
      decoration: _gal,
      clipBehavior: Clip.antiAlias,
      child: LayoutBuilder(builder: (c, box) {
        final w = box.maxWidth, h = box.maxHeight;
        final kids = <Widget>[
          _ring(w * .5, h * .44), _ring(w * .88, h * .8),
          Positioned.fill(child: CustomPaint(painter: _Lines(lines))),
          Center(child: _core()),
        ];
        for (var k = 0; k < ord.length; k++) {
          final i = ord[k].$1, p = pos[i]!;
          final last = st.chats[i]?.last.$2;
          kids.add(Positioned(
            left: w * p.dx / 100 - 48, top: h * p.dy / 100 - 30, width: 96,
            child: Opacity(
              opacity: 1 - k * .1,
              child: GestureDetector(
                onTap: () => context.push('/chat/$i'),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                    Av(i, 58 - k * 5.0),
                    Text(uname(context, i), style: const TextStyle(color: Color(0xFFE8E4FF), fontSize: 12, fontWeight: FontWeight.w700)),
                    Text(last == null ? Str.t(context, 'hi') : (stickerId(last) != null ? '✦ ${Str.t(context, 'sticker')}' : last),
                        maxLines: 1, overflow: TextOverflow.ellipsis,
                        style: const TextStyle(color: Color(0xCCE8E4FF), fontSize: 10)),
                ]),
              ),
            ),
          ));
        }
        kids.add(Positioned(
          left: 0, right: 0, bottom: 8,
          child: Text(Str.t(context, 'chint'), textAlign: TextAlign.center,
              style: const TextStyle(color: Color(0xB3E8E4FF), fontSize: 11)),
        ));
        return Stack(children: kids);
      }),
    );
  }
}

class _Lines extends CustomPainter {
  _Lines(this.l);
  final List<(Offset, Offset)> l;
  @override
  void paint(Canvas canvas, Size s) {
    final p = Paint()..color = const Color(0x5900E5FF)..strokeWidth = 1;
    for (final (a, b) in l) {
      canvas.drawLine(Offset(a.dx * s.width / 100, a.dy * s.height / 100), Offset(b.dx * s.width / 100, b.dy * s.height / 100), p);
    }
  }
  @override
  bool shouldRepaint(covariant _Lines o) => true;
}
