import 'package:flutter/material.dart';
import 'package:go_router/go_router.dart';
import 'package:provider/provider.dart';
import '../core/assets.dart';
import '../core/auth_service.dart';
import '../core/ble_service.dart';
import '../core/chat_repo.dart';
import '../core/settings.dart';
import '../core/strings.dart';

class Shell extends StatefulWidget {
  const Shell(this.nav, {super.key});
  final StatefulNavigationShell nav;
  @override
  State<Shell> createState() => _ShellState();
}

class _ShellState extends State<Shell> {
  @override
  void initState() {
    super.initState();
    if (AuthService.ready && AuthService.user != null) {
      final on = context.read<AppSettings>().nearby;
      ChatRepo.start().then((_) { if (on) BleService.start(); });
    }
  }
  @override
  Widget build(BuildContext context) => _ShellBody(widget.nav);
}

class _ShellBody extends StatelessWidget {
  const _ShellBody(this.nav);
  final StatefulNavigationShell nav;
  @override
  Widget build(BuildContext context) {
    String t(String k) => Str.t(context, k);
    PopupMenuItem<String> item(String v, String icon) => PopupMenuItem(
        value: v, child: Row(children: [Ic(icon, 28), const SizedBox(width: 10), Text(t(v))]));
    return Scaffold(
      appBar: AppBar(
        title: PopupMenuButton<String>(
          onSelected: (v) => context.push('/$v'),
          itemBuilder: (_) => [item('profile', 'profile'), item('settings', 'settings')],
          child: Container(
            padding: const EdgeInsetsDirectional.fromSTEB(12, 6, 16, 6),
            decoration: BoxDecoration(
              color: Theme.of(context).cardColor,
              borderRadius: BorderRadius.circular(999),
              border: Border.all(color: const Color(0x2E7B3FE4)),
            ),
            child: Row(mainAxisSize: MainAxisSize.min, children: [
              Image.asset('assets/logo/aura_icon.png', width: 28, height: 28),
              const SizedBox(width: 8),
              const Text('AURA ▾', style: TextStyle(fontWeight: FontWeight.w800, letterSpacing: 3)),
            ]),
          ),
        ),
      ),
      body: nav,
      bottomNavigationBar: _Nav(nav),
    );
  }
}

class _Nav extends StatelessWidget {
  const _Nav(this.nav);
  final StatefulNavigationShell nav;
  @override
  Widget build(BuildContext context) {
    Widget tab(int idx, String icon) => Expanded(
          child: InkResponse(
            onTap: () => nav.goBranch(idx, initialLocation: idx == nav.currentIndex),
            child: Padding(
              padding: const EdgeInsets.symmetric(vertical: 10),
              child: Opacity(opacity: nav.currentIndex == idx ? 1 : .6, child: Center(child: Ic(icon, 34))),
            ),
          ),
        );
    return SafeArea(
      child: Padding(
        padding: const EdgeInsets.fromLTRB(14, 8, 14, 12),
        child: Center(
          heightFactor: 1,
          child: ConstrainedBox(
            constraints: const BoxConstraints(maxWidth: 400),
            child: Container(
              padding: const EdgeInsets.symmetric(horizontal: 8, vertical: 4),
              decoration: BoxDecoration(
                color: const Color(0xEB14103A),
                borderRadius: BorderRadius.circular(34),
                border: Border.all(color: const Color(0x4DC9B8FF)),
              ),
              child: Row(children: [
                tab(0, 'home'),
                tab(1, 'reels'),
                GestureDetector(
                  onTap: () => context.push('/ai'),
                  child: Transform.translate(
                    offset: const Offset(0, -14),
                    child: Container(
                      width: 58, height: 58,
                      padding: const EdgeInsets.all(7),
                      decoration: BoxDecoration(
                        shape: BoxShape.circle, color: const Color(0xFF0A0A1E),
                        border: Border.all(color: Colors.white38),
                        boxShadow: const [BoxShadow(color: Color(0x8000E5FF), blurRadius: 18), BoxShadow(color: Color(0x667B3FE4), blurRadius: 30)],
                      ),
                      child: Image.asset('assets/logo/aura_icon.png'),
                    ),
                  ),
                ),
                tab(2, 'messages'),
                tab(3, 'friends'),
                Expanded(
                  child: InkResponse(
                    onTap: () => context.push('/services'),
                    child: const Padding(padding: EdgeInsets.symmetric(vertical: 8), child: Center(child: Ic('services', 42))),
                  ),
                ),
              ]),
            ),
          ),
        ),
      ),
    );
  }
}
