import 'package:flutter/material.dart';
import 'package:provider/provider.dart';
import '../core/demo.dart';
import '../core/state.dart';
import '../core/strings.dart';
import 'sky.dart';

class FriendsPage extends StatefulWidget {
  const FriendsPage({super.key});
  @override
  State<FriendsPage> createState() => _FriendsPageState();
}

class _FriendsPageState extends State<FriendsPage> {
  String q = '';
  @override
  Widget build(BuildContext context) {
    final st = context.watch<AppState>();
    String t(String k) => Str.t(context, k);
    Widget row(int i, List<Widget> actions) => ListTile(
          leading: Av(i, 44), title: Text(uname(context, i)),
          subtitle: Text('@${kUsers[i].$1} · ${t('orbit')}: ${t(st.orb[i] == 1 ? 'outer' : 'inner')}'),
          trailing: Row(mainAxisSize: MainAxisSize.min, children: actions),
        );
    final found = [for (var i = 0; i < kUsers.length; i++) if (kUsers[i].$1.contains(q.toLowerCase().trim())) i];
    return ListView(children: [
      OrbitSky(height: 300, hintKey: 'ohint', onTap: st.toggleOrb),
      Padding(
        padding: const EdgeInsets.symmetric(horizontal: 12),
        child: TextField(
          decoration: InputDecoration(hintText: t('search_u'), border: const OutlineInputBorder(borderRadius: BorderRadius.all(Radius.circular(12)))),
          onChanged: (v) => setState(() => q = v),
        ),
      ),
      if (st.reqs.isNotEmpty) Padding(padding: const EdgeInsets.fromLTRB(16, 16, 16, 0), child: Text(t('req'))),
      for (final i in List<int>.of(st.reqs))
        row(i, [
          FilledButton(onPressed: () => st.removeReq(i), child: Text(t('accept'))),
          const SizedBox(width: 6),
          OutlinedButton(onPressed: () => st.removeReq(i), child: Text(t('decline'))),
        ]),
      const Divider(),
      for (final i in found)
        row(i, [
          OutlinedButton(onPressed: () => st.toggleOrb(i), child: Text(t('move'))),
          const SizedBox(width: 6),
          st.added.contains(i) ? Text(t('sent')) : FilledButton(onPressed: () => st.addFriend(i), child: Text(t('add'))),
        ]),
      const SizedBox(height: 16),
    ]);
  }
}
