import 'package:firebase_core/firebase_core.dart';

/// قالب إعدادات Firebase (Android). إن بقيت القيم PUT_... يعمل التطبيق في وضع تجريبي بلا حسابات.
/// عند البناء عبر GitHub Actions تُستبدل القيم تلقائياً من Secrets. وإن شغّلت `flutterfire configure`
/// على حاسوب فسيستبدل هذا الملف بملفه الخاص (وفيه نفس الاسم currentPlatform).
class DefaultFirebaseOptions {
  static const apiKey = 'PUT_API_KEY';
  static const appId = 'PUT_APP_ID';
  static const messagingSenderId = 'PUT_SENDER_ID';
  static const projectId = 'PUT_PROJECT_ID';

  static FirebaseOptions get currentPlatform {
    if (apiKey.startsWith('PUT_') || apiKey.isEmpty) throw UnsupportedError('Firebase not configured');
    return const FirebaseOptions(apiKey: apiKey, appId: appId, messagingSenderId: messagingSenderId, projectId: projectId);
  }
}
