import 'package:go_router/go_router.dart';
import 'auth_service.dart';
import '../features/auth_page.dart';
import '../features/shell.dart';
import '../features/home_page.dart';
import '../features/reels_page.dart';
import '../features/friends_page.dart';
import '../features/messages_page.dart';
import '../features/ai_page.dart';
import '../features/profile_page.dart';
import '../features/services_page.dart';
import '../features/section_page.dart';
import '../features/settings_page.dart';
import '../features/story_page.dart';
import '../features/notes_page.dart';
import '../features/media_page.dart';
import '../features/real_social.dart';
import '../features/nearby_page.dart';
import '../features/wiki_page.dart';
import '../features/games/games_page.dart';

GoRouter buildRouter() => GoRouter(
    redirect: (c, s) {
      if (!AuthService.ready) return s.matchedLocation == '/auth' ? '/' : null;
      final ok = AuthService.user != null && AuthService.hasUsername;
      if (!ok && s.matchedLocation != '/auth') return '/auth';
      return null;
    },
    routes: [
      GoRoute(path: '/auth', builder: (c, s) => const AuthPage()),
      StatefulShellRoute.indexedStack(
        builder: (c, s, nav) => Shell(nav),
        branches: [
          StatefulShellBranch(routes: [GoRoute(path: '/', builder: (c, s) => const HomePage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/reels', builder: (c, s) => const ReelsPage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/messages', builder: (c, s) => AuthService.ready ? const RealMessagesPage() : const MessagesPage())]),
          StatefulShellBranch(routes: [GoRoute(path: '/friends', builder: (c, s) => AuthService.ready ? const RealFriendsPage() : const FriendsPage())]),
        ],
      ),
      GoRoute(path: '/ai', builder: (c, s) => const AiPage()),
      GoRoute(path: '/profile', builder: (c, s) => const ProfilePage()),
      GoRoute(path: '/services', builder: (c, s) => const ServicesPage()),
      GoRoute(path: '/settings', builder: (c, s) => const SettingsPage()),
      GoRoute(path: '/s/games', builder: (c, s) => const GamesPage()),
      GoRoute(path: '/s/notes', builder: (c, s) => const NotesPage()),
      GoRoute(path: '/s/wiki', builder: (c, s) => const WikiPage()),
      GoRoute(path: '/game/:id', builder: (c, s) => GamePage(id: s.pathParameters['id']!)),
      GoRoute(path: '/note/:id', builder: (c, s) => NoteEditor(id: int.parse(s.pathParameters['id']!))),
      GoRoute(path: '/s/nearby', builder: (c, s) => const NearbyPage()),
      GoRoute(path: '/s/files', builder: (c, s) => const MediaPage(videos: false)),
      GoRoute(path: '/s/videos', builder: (c, s) => const MediaPage(videos: true)),
      GoRoute(path: '/player', builder: (c, s) {
        final m = s.extra as Map<String, Object?>;
        return PlayerPage(path: m['path'] as String, name: m['name'] as String);
      }),
      GoRoute(path: '/s/:id', builder: (c, s) => SectionPage(id: s.pathParameters['id']!)),
      GoRoute(path: '/rchat/:pid', builder: (c, s) => RealChatPage(pid: s.pathParameters['pid']!, name: (s.extra as String?) ?? '')),
      GoRoute(path: '/chat/:i', builder: (c, s) => ChatPage(i: int.parse(s.pathParameters['i']!))),
      GoRoute(path: '/story/:i', builder: (c, s) => StoryPage(i: int.parse(s.pathParameters['i']!))),
    ]);
