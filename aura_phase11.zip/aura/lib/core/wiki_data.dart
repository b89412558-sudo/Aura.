/// موسوعة مدمجة تعمل دون إنترنت: [عنوان عربي، English، نص عربي، English text]
const kWiki = <List<String>>[
  ['مجرة درب التبانة', 'Milky Way', 'مجرة حلزونية تضم نظامنا الشمسي وتحتوي مئات المليارات من النجوم.', 'A spiral galaxy that holds our Solar System and hundreds of billions of stars.'],
  ['الشمس', 'The Sun', 'نجم في مركز نظامنا الشمسي، عمره نحو 4.6 مليار سنة، ويحوي نحو 99.8% من كتلة النظام الشمسي.', 'The star at the center of our Solar System, about 4.6 billion years old, holding about 99.8% of its mass.'],
  ['القمر', 'The Moon', 'التابع الطبيعي الوحيد للأرض، يبعد نحو 384,400 كم ويدور حولها في نحو 27.3 يوماً.', 'Earth\'s only natural satellite, about 384,400 km away, orbiting every 27.3 days.'],
  ['المريخ', 'Mars', 'الكوكب الرابع من الشمس ويُعرف بالأحمر بسبب أكسيد الحديد في تربته، وله قمران: فوبوس وديموس.', 'The fourth planet, called the Red Planet for the iron oxide in its soil. It has two moons: Phobos and Deimos.'],
  ['المشتري', 'Jupiter', 'أكبر كواكب النظام الشمسي، عملاق غازي، وبقعته الحمراء العظيمة عاصفة ضخمة.', 'The largest planet, a gas giant. Its Great Red Spot is a huge storm.'],
  ['زحل', 'Saturn', 'عملاق غازي مشهور بحلقاته المكوّنة في معظمها من جليد وصخور.', 'A gas giant famous for rings made mostly of ice and rock.'],
  ['الثقب الأسود', 'Black hole', 'منطقة جاذبيتها قوية لدرجة أن لا شيء، حتى الضوء، يستطيع الإفلات منها بعد أفق الحدث.', 'A region whose gravity is so strong nothing, not even light, can escape past the event horizon.'],
  ['السديم', 'Nebula', 'سحابة هائلة من الغاز والغبار في الفضاء، وتتشكل داخل كثير منها نجوم جديدة.', 'A vast cloud of gas and dust in space; many new stars form inside nebulae.'],
  ['السنة الضوئية', 'Light-year', 'المسافة التي يقطعها الضوء في سنة، وتساوي نحو 9.46 تريليون كيلومتر.', 'The distance light travels in a year, about 9.46 trillion kilometers.'],
  ['المستعر الأعظم', 'Supernova', 'انفجار هائل يحدث في نهاية حياة بعض النجوم الضخمة.', 'A huge explosion at the end of the life of some massive stars.'],
  ['المذنّب', 'Comet', 'جرم جليدي يتكوّن له ذيل من الغاز والغبار عند اقترابه من الشمس.', 'An icy body that grows a tail of gas and dust as it nears the Sun.'],
  ['أندروميدا', 'Andromeda', 'أقرب مجرة حلزونية كبيرة لمجرتنا، وتبعد نحو 2.5 مليون سنة ضوئية.', 'The nearest large spiral galaxy to ours, about 2.5 million light-years away.'],
];
