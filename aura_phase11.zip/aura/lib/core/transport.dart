/// وسيلة نقل الرسائل (إنترنت/Firestore، Bluetooth...). الرسالة تُحفظ محلياً أولاً دائماً،
/// ثم يُحاول التطبيق إرسالها عبر أي وسيلة متاحة. لا توجد وسائل مسجّلة بعد (Bluetooth غير منفَّذ).
abstract class Transport {
  String get name;
  Future<bool> get available;
  Future<bool> send(int peer, String text);
}

class Transports {
  static final List<Transport> all = [];

  /// يعيد true إذا نجحت وسيلة واحدة على الأقل في الإرسال.
  static Future<bool> trySend(int peer, String text) async {
    for (final t in all) {
      try {
        if (await t.available && await t.send(peer, text)) return true;
      } catch (_) {}
    }
    return false;
  }
}
