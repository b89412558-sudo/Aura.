import 'dart:convert';
import 'package:flutter/foundation.dart';
import 'local_store.dart';
import 'transport.dart';

/// حالة التطبيق. تُحفظ محلياً (SQLite) فتبقى بعد إغلاق التطبيق وتعمل دون إنترنت.
/// الأصدقاء والمحتوى ما زالوا تجريبيين حتى يُربط Firestore/Bluetooth.
class AppState extends ChangeNotifier {
  final Map<int, int> orb = {0: 0, 1: 0, 2: 0, 3: 1, 4: 1, 5: 1}; // 0 قريب، 1 بعيد
  final Map<int, List<(bool, String)>> chats = {};
  final Map<String, String> rx = {}; // 'p0' -> id الإيموجي
  final Set<int> seen = {};
  final List<int> reqs = [2, 4];
  final Set<int> added = {};
  final Map<String, int> best = {}; // أفضل نتيجة لكل لعبة
  LocalStore? store;

  Future<void> load(LocalStore? s) async {
    store = s;
    if (s == null) return;
    try {
      for (final m in await s.messages()) {
        (chats[m['peer'] as int] ??= []).add(((m['me'] as int) == 1, m['text'] as String));
      }
      final o = await s.get('orb');
      if (o != null) { (jsonDecode(o) as Map).forEach((k, v) { orb[int.parse(k as String)] = v as int; }); }
      final r = await s.get('rx');
      if (r != null) { (jsonDecode(r) as Map).forEach((k, v) { rx[k as String] = v as String; }); }
      final bs = await s.get('best');
      if (bs != null) { (jsonDecode(bs) as Map).forEach((k, v) { best[k as String] = v as int; }); }
      final se = await s.get('seen');
      if (se != null) { seen.addAll((jsonDecode(se) as List).cast<int>()); }
    } catch (_) {/* قاعدة تالفة: نكمل بحالة فارغة */}
  }

  void _kv(String k, Object v) { store?.set(k, jsonEncode(v)).catchError((_) {}); }

  void toggleOrb(int i) {
    orb[i] = 1 - orb[i]!;
    _kv('orb', orb.map((k, v) => MapEntry('$k', v)));
    notifyListeners();
  }

  void setRx(String k, String? v) {
    if (v == null) { rx.remove(k); } else { rx[k] = v; }
    _kv('rx', rx);
    notifyListeners();
  }

  void send(int i, String text, String hello) {
    if (chats[i] == null) {
      chats[i] = [(false, hello)];
      store?.addMessage(i, false, hello).catchError((_) {});
    }
    chats[i]!.add((true, text));
    store?.addMessage(i, true, text).catchError((_) {}); // يُحفظ محلياً أولاً دائماً
    Transports.trySend(i, text); // ثم يُحاول النقل عبر أي وسيلة متاحة (لا توجد بعد)
    notifyListeners();
  }

  int bestOf(String id, int v, {bool low = false}) {
    final o = best[id];
    if (o == null || (low ? v < o : v > o)) { best[id] = v; _kv('best', best); notifyListeners(); }
    return best[id]!;
  }

  void markSeen(int i) {
    if (seen.add(i)) { _kv('seen', seen.toList()); notifyListeners(); }
  }

  void removeReq(int i) { reqs.remove(i); notifyListeners(); }
  void addFriend(int i) { added.add(i); notifyListeners(); }
}
