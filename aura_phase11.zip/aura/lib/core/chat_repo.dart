import 'dart:async';
import 'dart:math';
import 'package:cloud_firestore/cloud_firestore.dart';
import 'auth_service.dart';
import 'ble_service.dart';
import 'crypto_service.dart';
import 'local_store.dart';
import 'social_service.dart';

/// المحادثات «محلية أولاً»: كل رسالة تُحفظ في SQLite ثم تُرسل عبر Firestore (إنترنت) و/أو Bluetooth (صديق قريب).
/// الاستقبال من أي وسيلة يُحفظ محلياً بلا تكرار (المعرّف فريد).
class ChatRepo {
  static LocalStore? store;
  static final _ctl = StreamController<String>.broadcast();
  static final Map<String, StreamSubscription<dynamic>> _subs = {};
  static StreamSubscription<dynamic>? _friendsSub;
  static bool started = false;

  static void notify(String pid) => _ctl.add(pid);
  static String newId() => '${DateTime.now().microsecondsSinceEpoch.toRadixString(36)}${Random().nextInt(1 << 20).toRadixString(36)}';

  static Future<List<ChatMsg>> _load(String pid) async {
    final s = store;
    if (s == null) return [];
    return [for (final m in await s.lmsgs(pid)) ChatMsg(m['id'] as String, m['from_uid'] as String, m['text'] as String, m['status'] as String)];
  }

  static Stream<List<ChatMsg>> watch(String pid) async* {
    yield await _load(pid);
    await for (final p in _ctl.stream) {
      if (p == pid) yield await _load(pid);
    }
  }

  static Future<void> send(String pid, String text) async {
    final s = store;
    if (s == null || text.trim().isEmpty) return;
    final id = newId(), ts = DateTime.now().millisecondsSinceEpoch;
    await s.addLocalMsg({'id': id, 'pid': pid, 'from_uid': SocialService.me, 'text': text.trim(), 'ts': ts, 'status': 'pending'});
    notify(pid);
    SocialService.putMessage(pid, id, text.trim(), ts).then((_) async {
      await s.setLStatus(id, 'server');
      notify(pid);
    }).catchError((_) {});
    BleService.requestFlush();
  }

  static Future<void> start() async {
    if (started || !AuthService.ready || AuthService.user == null) return;
    started = true;
    final uid = SocialService.me;
    try {
      await CryptoService.init(uid);
      await FirebaseFirestore.instance.collection('users').doc(uid).update({'pk': CryptoService.myPublicB64});
    } catch (_) {/* بلا إنترنت: يُنشر المفتاح لاحقاً */}
    _friendsSub = SocialService.friends().listen((fs) async {
      for (final f in fs) {
        await store?.upsertPeer(f.uid, f.pairId, f.username);
        _attach(f.pairId);
        _fetchPk(f.uid);
      }
    }, onError: (_) {});
  }

  static Future<void> stop() async {
    started = false;
    await _friendsSub?.cancel();
    for (final s in _subs.values) { await s.cancel(); }
    _subs.clear();
    await BleService.stop();
  }

  static void _attach(String pid) {
    if (_subs.containsKey(pid)) return;
    _subs[pid] = SocialService.rawMessages(pid).listen((snap) async {
      final s = store;
      if (s == null) return;
      for (final d in snap.docs) {
        if (d.metadata.hasPendingWrites) continue;
        final m = d.data();
        final from = m['from'] as String;
        final t = m['ts'];
        final ts = t is Timestamp ? t.millisecondsSinceEpoch : DateTime.now().millisecondsSinceEpoch;
        final isNew = await s.addLocalMsg({'id': d.id, 'pid': pid, 'from_uid': from, 'text': m['text'], 'ts': ts, 'status': 'server'});
        if (!isNew && from == SocialService.me) { await s.setLStatus(d.id, 'server'); }
      }
      notify(pid);
    }, onError: (_) {});
  }

  static Future<void> _fetchPk(String uid) async {
    try {
      if (await store?.peerPk(uid) != null) return;
      final d = await FirebaseFirestore.instance.collection('users').doc(uid).get();
      final pk = d.data()?['pk'] as String?;
      if (pk != null) { await store?.setPeerPk(uid, pk); }
    } catch (_) {}
  }
}
