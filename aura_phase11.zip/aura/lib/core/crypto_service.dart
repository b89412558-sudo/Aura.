import 'dart:convert';
import 'package:cryptography/cryptography.dart';
import 'package:flutter_secure_storage/flutter_secure_storage.dart';

/// تشفير رسائل Bluetooth بين صديقين: X25519 (مفتاح مشترك ثابت) + HKDF + AES-256-GCM.
/// المفتاح العام يُنشر في users/{uid}.pk عند توفر الإنترنت، ويُخزَّن عند الأصدقاء. المفتاح الخاص في التخزين الآمن للجهاز.
/// لا سرية أمامية (forward secrecy)، ولا حماية من جهاز مسروق مفتوح.
class CryptoService {
  static final _x = X25519();
  static final _aes = AesGcm.with256bits();
  static final _kdf = Hkdf(hmac: Hmac.sha256(), outputLength: 32);
  static const _st = FlutterSecureStorage();
  static SimpleKeyPair? _kp;
  static String? myPublicB64;

  static Future<void> init(String uid) async {
    final k = 'sk_$uid';
    final saved = await _st.read(key: k);
    if (saved != null) {
      final m = jsonDecode(saved) as Map;
      _kp = SimpleKeyPairData(base64Decode(m['s'] as String),
          publicKey: SimplePublicKey(base64Decode(m['p'] as String), type: KeyPairType.x25519), type: KeyPairType.x25519);
    } else {
      final kp = await _x.newKeyPair();
      final pub = await kp.extractPublicKey();
      await _st.write(key: k, value: jsonEncode({'s': base64Encode(await kp.extractPrivateKeyBytes()), 'p': base64Encode(pub.bytes)}));
      _kp = kp;
    }
    myPublicB64 = base64Encode((await _kp!.extractPublicKey()).bytes);
  }

  static Future<SecretKey> _key(String peerPkB64) async {
    final shared = await _x.sharedSecretKey(
        keyPair: _kp!, remotePublicKey: SimplePublicKey(base64Decode(peerPkB64), type: KeyPairType.x25519));
    return _kdf.deriveKey(secretKey: shared, nonce: utf8.encode('aura-v1'), info: utf8.encode('chat'));
  }

  static Future<String> encrypt(String peerPkB64, String plain, String aad) async {
    final box = await _aes.encrypt(utf8.encode(plain), secretKey: await _key(peerPkB64), aad: utf8.encode(aad));
    return base64Encode(box.concatenation());
  }

  static Future<String?> decrypt(String peerPkB64, String b64, String aad) async {
    try {
      final box = SecretBox.fromConcatenation(base64Decode(b64), nonceLength: 12, macLength: 16);
      return utf8.decode(await _aes.decrypt(box, secretKey: await _key(peerPkB64), aad: utf8.encode(aad)));
    } catch (_) {
      return null;
    }
  }
}
