import 'package:path/path.dart' as p;
import 'package:sqflite/sqflite.dart';

/// قاعدة بيانات محلية (SQLite) تعمل دون إنترنت: الرسائل + إعدادات صغيرة (مفتاح/قيمة).
class LocalStore {
  LocalStore._(this._db);
  final Database _db;

  static Future<LocalStore> open() async {
    final path = p.join(await getDatabasesPath(), 'aura.db');
    final db = await openDatabase(path, version: 4, onCreate: (d, v) async {
      await d.execute('CREATE TABLE messages(id INTEGER PRIMARY KEY AUTOINCREMENT, peer INTEGER NOT NULL, me INTEGER NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL)');
      await d.execute('CREATE INDEX idx_msg_peer ON messages(peer, ts)');
      await d.execute('CREATE TABLE kv(k TEXT PRIMARY KEY, v TEXT NOT NULL)');
      await d.execute('CREATE TABLE notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL)');
      await d.execute('CREATE TABLE media(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, path TEXT NOT NULL, kind TEXT NOT NULL, ts INTEGER NOT NULL)');
      await d.execute('CREATE TABLE IF NOT EXISTS lmsgs(id TEXT PRIMARY KEY, pid TEXT NOT NULL, from_uid TEXT NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL, status TEXT NOT NULL)');
      await d.execute('CREATE INDEX IF NOT EXISTS idx_lmsgs_pid ON lmsgs(pid, ts)');
      await d.execute('CREATE TABLE IF NOT EXISTS peers(uid TEXT PRIMARY KEY, pid TEXT NOT NULL, username TEXT NOT NULL, pk TEXT)');
    }, onUpgrade: (d, o, n) async {
      if (o < 4) {
        await d.execute('CREATE TABLE IF NOT EXISTS lmsgs(id TEXT PRIMARY KEY, pid TEXT NOT NULL, from_uid TEXT NOT NULL, text TEXT NOT NULL, ts INTEGER NOT NULL, status TEXT NOT NULL)');
        await d.execute('CREATE INDEX IF NOT EXISTS idx_lmsgs_pid ON lmsgs(pid, ts)');
        await d.execute('CREATE TABLE IF NOT EXISTS peers(uid TEXT PRIMARY KEY, pid TEXT NOT NULL, username TEXT NOT NULL, pk TEXT)');
      }
      if (o < 3) {
        await d.execute('CREATE TABLE IF NOT EXISTS media(id INTEGER PRIMARY KEY AUTOINCREMENT, name TEXT NOT NULL, path TEXT NOT NULL, kind TEXT NOT NULL, ts INTEGER NOT NULL)');
      }
      if (o < 2) {
        await d.execute('CREATE TABLE IF NOT EXISTS notes(id INTEGER PRIMARY KEY AUTOINCREMENT, title TEXT NOT NULL, body TEXT NOT NULL, ts INTEGER NOT NULL)');
      }
    });
    return LocalStore._(db);
  }

  Future<List<Map<String, Object?>>> messages() => _db.query('messages', orderBy: 'ts ASC, id ASC');

  Future<void> addMessage(int peer, bool me, String text) async {
    await _db.insert('messages', {'peer': peer, 'me': me ? 1 : 0, 'text': text, 'ts': DateTime.now().millisecondsSinceEpoch});
  }

  Future<String?> get(String k) async {
    final r = await _db.query('kv', where: 'k = ?', whereArgs: [k]);
    return r.isEmpty ? null : r.first['v'] as String;
  }

  Future<void> set(String k, String v) async {
    await _db.insert('kv', {'k': k, 'v': v}, conflictAlgorithm: ConflictAlgorithm.replace);
  }

  Future<List<Map<String, Object?>>> notes() => _db.query('notes', orderBy: 'ts DESC');

  Future<int> saveNote(int? id, String title, String body) async {
    final v = {'title': title, 'body': body, 'ts': DateTime.now().millisecondsSinceEpoch};
    if (id == null) { return _db.insert('notes', v); }
    await _db.update('notes', v, where: 'id = ?', whereArgs: [id]);
    return id;
  }

  Future<void> deleteNote(int id) async { await _db.delete('notes', where: 'id = ?', whereArgs: [id]); }

  Future<List<Map<String, Object?>>> media(bool videosOnly) =>
      _db.query('media', where: videosOnly ? "kind = 'video'" : null, orderBy: 'ts DESC');

  Future<void> addMedia(String name, String path, String kind) async {
    await _db.insert('media', {'name': name, 'path': path, 'kind': kind, 'ts': DateTime.now().millisecondsSinceEpoch});
  }

  Future<void> deleteMedia(int id) async { await _db.delete('media', where: 'id = ?', whereArgs: [id]); }

  // ---- رسائل محلية أولاً + أصدقاء مخزّنون (للتواصل عبر Bluetooth) ----
  Future<bool> addLocalMsg(Map<String, Object?> m) async {
    final r = await _db.insert('lmsgs', m, conflictAlgorithm: ConflictAlgorithm.ignore);
    return r != 0;
  }

  Future<List<Map<String, Object?>>> lmsgs(String pid) =>
      _db.query('lmsgs', where: 'pid = ?', whereArgs: [pid], orderBy: 'ts ASC');

  Future<void> setLStatus(String id, String status) async {
    await _db.update('lmsgs', {'status': status}, where: 'id = ?', whereArgs: [id]);
  }

  /// رسائلي التي لم تصل لأي وسيلة بعد، إلى هذه المحادثة.
  Future<List<Map<String, Object?>>> pendingTo(String pid, String me) =>
      _db.query('lmsgs', where: "pid = ? AND from_uid = ? AND status = 'pending'", whereArgs: [pid, me], orderBy: 'ts ASC');

  Future<int> pendingCount(String me) async {
    final r = await _db.rawQuery("SELECT COUNT(*) AS n FROM lmsgs WHERE from_uid = ? AND status = 'pending'", [me]);
    return (r.first['n'] as int?) ?? 0;
  }

  Future<void> upsertPeer(String uid, String pid, String username) async {
    final r = await _db.query('peers', where: 'uid = ?', whereArgs: [uid]);
    if (r.isEmpty) { await _db.insert('peers', {'uid': uid, 'pid': pid, 'username': username}); }
    else { await _db.update('peers', {'pid': pid, 'username': username}, where: 'uid = ?', whereArgs: [uid]); }
  }

  Future<void> setPeerPk(String uid, String pk) async {
    await _db.update('peers', {'pk': pk}, where: 'uid = ?', whereArgs: [uid]);
  }

  Future<String?> peerPk(String uid) async {
    final r = await _db.query('peers', columns: ['pk'], where: 'uid = ?', whereArgs: [uid]);
    return r.isEmpty ? null : r.first['pk'] as String?;
  }

  Future<Map<String, Object?>?> peer(String uid) async {
    final r = await _db.query('peers', where: 'uid = ?', whereArgs: [uid]);
    return r.isEmpty ? null : r.first;
  }

  Future<List<Map<String, Object?>>> peers() => _db.query('peers');
}
