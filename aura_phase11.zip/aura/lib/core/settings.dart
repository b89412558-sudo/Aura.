import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// يحفظ المظهر واللغة محلياً. الافتراضي: فاتح + عربي.
class AppSettings extends ChangeNotifier {
  AppSettings._(this._p)
      : themeMode = _parse(_p.getString('theme')),
        locale = Locale(_p.getString('lang') ?? 'ar'),
        nearby = _p.getBool('nearby') ?? false;
  final SharedPreferences _p;
  ThemeMode themeMode;
  Locale locale;
  bool nearby; // التواصل عبر Bluetooth (مطفأ افتراضياً لتوفير البطارية)

  static Future<AppSettings> load() async =>
      AppSettings._(await SharedPreferences.getInstance());

  static ThemeMode _parse(String? v) => switch (v) {
        'dark' => ThemeMode.dark,
        'system' => ThemeMode.system,
        _ => ThemeMode.light,
      };

  void setTheme(ThemeMode m) {
    themeMode = m;
    _p.setString('theme', m.name);
    notifyListeners();
  }

  void setLang(String code) {
    locale = Locale(code);
    _p.setString('lang', code);
    notifyListeners();
  }

  void setNearby(bool v) {
    nearby = v;
    _p.setBool('nearby', v);
    notifyListeners();
  }
}
