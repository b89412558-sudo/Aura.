import 'package:flutter/material.dart';

class AuraColors {
  static const blue = Color(0xFF2F6BFF);
  static const cyan = Color(0xFF00E5FF);
  static const violet = Color(0xFF7B3FE4);
  static const lavender = Color(0xFFC9B8FF);
}

class AuraTheme {
  static ThemeData _base(Brightness b) {
    final cs = ColorScheme.fromSeed(
        seedColor: AuraColors.blue, secondary: AuraColors.cyan,
        tertiary: AuraColors.violet, brightness: b);
    return ThemeData(
      useMaterial3: true,
      colorScheme: cs,
      scaffoldBackgroundColor: b == Brightness.dark ? const Color(0xFF0A0A1E) : const Color(0xFFF7F7FD),
      appBarTheme: const AppBarTheme(centerTitle: true, elevation: 0),
      pageTransitionsTheme: const PageTransitionsTheme(builders: {
        TargetPlatform.android: FadeUpwardsPageTransitionsBuilder(),
        TargetPlatform.iOS: CupertinoPageTransitionsBuilder(),
      }),
    );
  }
  static final light = _base(Brightness.light);
  static final dark = _base(Brightness.dark);
}
