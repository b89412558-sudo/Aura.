import 'package:flutter/material.dart';

const kEmoji = ['burst', 'thumbs', 'heart', 'laugh', 'star_eyes', 'party', 'alien', 'robot', 'rocket', 'gem', 'nebula_heart', 'flower'];
const kReacts = ['burst', 'heart', 'thumbs', 'laugh', 'star_eyes'];

class Ic extends StatelessWidget {
  const Ic(this.name, this.size, {super.key});
  final String name;
  final double size;
  @override
  Widget build(BuildContext c) => Image.asset('assets/icons/$name.png',
      width: size, height: size, cacheWidth: (size * 2.5).round());
}

class Emo extends StatelessWidget {
  const Emo(this.id, this.size, {super.key});
  final String id;
  final double size;
  @override
  Widget build(BuildContext c) => Image.asset('assets/emoji/$id.png',
      width: size, height: size, cacheWidth: (size * 2.5).round());
}

final RegExp kStickerRe = RegExp(r'^:([a-z_]+):$');
String? stickerId(String s) {
  final m = kStickerRe.firstMatch(s);
  return (m != null && kEmoji.contains(m.group(1))) ? m.group(1) : null;
}

Widget logo(double size) => Image.asset('assets/logo/aura_icon.png', width: size, height: size);
