import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:shared_preferences/shared_preferences.dart';

/// الحسابات عبر Firebase: رقم الهاتف + رمز تحقق + اسم مستخدم فريد (غير حساس لحالة الأحرف).
/// رقم الهاتف يبقى في Firebase Auth فقط ولا يُكتب في Firestore (لا يظهر للآخرين).
class AuthService {
  static bool ready = false; // false = وضع تجريبي (Firebase غير مُعدّ)
  static bool hasUsername = false;
  static String? username, displayName;
  static FirebaseAuth get _a => FirebaseAuth.instance;
  static FirebaseFirestore get _db => FirebaseFirestore.instance;
  static User? get user => ready ? _a.currentUser : null;

  static final _re = RegExp(r'^[a-z0-9_]{3,20}$');

  static Future<void> sendCode(String phone,
      {required void Function(String vid) onSent, required void Function(String err) onError, required Future<void> Function() onAuto}) {
    return _a.verifyPhoneNumber(
      phoneNumber: phone,
      verificationCompleted: (c) async { await _a.signInWithCredential(c); await onAuto(); },
      verificationFailed: (e) => onError(e.message ?? e.code),
      codeSent: (vid, _) => onSent(vid),
      codeAutoRetrievalTimeout: (_) {},
    );
  }

  static Future<void> confirm(String vid, String code) =>
      _a.signInWithCredential(PhoneAuthProvider.credential(verificationId: vid, smsCode: code));

  /// يقرأ اسم المستخدم من Firestore، وعند انقطاع الإنترنت يعتمد على آخر نسخة محفوظة (يعمل دون إنترنت).
  static Future<void> refreshUsername() async {
    final u = user;
    if (u == null) { hasUsername = false; username = null; displayName = null; return; }
    final p = await SharedPreferences.getInstance();
    try {
      final d = (await _db.collection('users').doc(u.uid).get()).data();
      username = d?['username'] as String?;
      displayName = d?['displayName'] as String?;
      hasUsername = username != null;
      await p.setString('un_${u.uid}', username ?? '');
      await p.setString('dn_${u.uid}', displayName ?? '');
    } catch (_) {
      final un = p.getString('un_${u.uid}') ?? '';
      username = un.isEmpty ? null : un;
      displayName = p.getString('dn_${u.uid}');
      hasUsername = username != null;
    }
  }

  /// يعيد null عند النجاح، أو 'invalid' / 'taken' / 'error'.
  static Future<String?> claimUsername(String raw, String display) async {
    final name = raw.trim().toLowerCase();
    if (!_re.hasMatch(name) || display.trim().isEmpty) return 'invalid';
    final uid = user!.uid;
    try {
      await _db.runTransaction((tx) async {
        final ref = _db.collection('usernames').doc(name);
        if ((await tx.get(ref)).exists) throw 'taken';
        tx.set(ref, {'uid': uid});
        tx.set(_db.collection('users').doc(uid),
            {'username': name, 'displayName': display.trim(), 'createdAt': FieldValue.serverTimestamp()});
      });
      username = name;
      displayName = display.trim();
      hasUsername = true;
      final p = await SharedPreferences.getInstance();
      await p.setString('un_$uid', name);
      await p.setString('dn_$uid', displayName!);
      return null;
    } catch (e) {
      return e == 'taken' ? 'taken' : 'error';
    }
  }

  static Future<void> signOut() async {
    await _a.signOut();
    hasUsername = false; username = null; displayName = null;
  }
}
