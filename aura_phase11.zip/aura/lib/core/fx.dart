import 'dart:math';
import 'package:flutter/material.dart';
import 'assets.dart';

/// فرقعة كبيرة تتلاشى، ثم 3 لمعات صغيرة ثابتة الحجم تنجرف ببطء وتختفي.
void playBurst(BuildContext context, Offset center, String id) {
  final overlay = Overlay.of(context);
  late OverlayEntry e;
  e = OverlayEntry(builder: (_) => _Fx(center: center, id: id, onDone: () => e.remove()));
  overlay.insert(e);
}

class _Fx extends StatefulWidget {
  const _Fx({required this.center, required this.id, required this.onDone});
  final Offset center;
  final String id;
  final VoidCallback onDone;
  @override
  State<_Fx> createState() => _FxState();
}

class _FxState extends State<_Fx> with SingleTickerProviderStateMixin {
  late final AnimationController ac = AnimationController(vsync: this, duration: const Duration(seconds: 10))
    ..addStatusListener((s) { if (s == AnimationStatus.completed) widget.onDone(); })
    ..forward();
  final rnd = Random();
  // dx, dy (نسبة من الشاشة)، بداية الثواني، المدة
  late final List<List<double>> g = List.generate(
      3, (n) => [(rnd.nextDouble() - .5) * .55, (rnd.nextDouble() - .5) * .45, .5 + n * .35, 6.5 + rnd.nextDouble() * 2]);
  @override
  void dispose() { ac.dispose(); super.dispose(); }

  @override
  Widget build(BuildContext context) {
    final size = MediaQuery.of(context).size;
    final still = MediaQuery.of(context).disableAnimations;
    return IgnorePointer(
      child: AnimatedBuilder(
        animation: ac,
        builder: (_, __) {
          final s = ac.value * 10;
          final kids = <Widget>[];
          final u = (s / .8).clamp(0.0, 1.0);
          if (u < 1) {
            final op = u < .35 ? u / .35 : 1 - (u - .35) / .65;
            kids.add(Positioned(
              left: widget.center.dx - 95, top: widget.center.dy - 95,
              child: Opacity(opacity: op.clamp(0.0, 1.0),
                  child: Transform.scale(scale: .2 + 1.3 * u, child: Emo(widget.id, 190))),
            ));
          }
          if (!still) {
            for (final p in g) {
              final v = (s - p[2]) / p[3];
              if (v <= 0 || v >= 1) continue;
              final e = Curves.easeInOut.transform(v);
              final op = v < .2 ? .7 * v / .2 : (v < .7 ? .7 - .1 * (v - .2) / .5 : .6 * (1 - (v - .7) / .3));
              kids.add(Positioned(
                left: widget.center.dx + p[0] * size.width * e - 17,
                top: widget.center.dy + p[1] * size.height * e - 17,
                child: Opacity(
                  opacity: op.clamp(0.0, 1.0),
                  child: Container(
                    width: 34, height: 34,
                    decoration: const BoxDecoration(shape: BoxShape.circle,
                        boxShadow: [BoxShadow(color: Color(0x88FFD28C), blurRadius: 14)]),
                    child: Emo(widget.id, 34),
                  ),
                ),
              ));
            }
          }
          return Stack(children: kids);
        },
      ),
    );
  }
}
