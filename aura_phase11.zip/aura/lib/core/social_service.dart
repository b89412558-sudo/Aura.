import 'package:cloud_firestore/cloud_firestore.dart';
import 'auth_service.dart';

class FriendInfo {
  const FriendInfo(this.uid, this.pairId, this.username);
  final String uid, pairId, username;
}

class RequestInfo {
  const RequestInfo(this.pairId, this.from);
  final String pairId, from;
}

class ChatMsg {
  const ChatMsg(this.id, this.from, this.text, this.status);
  final String id, from, text;
  final String status; // pending = لم تصل لأي وسيلة، ble = وصلت عبر Bluetooth، server = وصلت للخادم
}

/// الأصدقاء والمحادثات عبر Firestore.
/// الرسائل: Firestore يحفظ الكتابات محلياً عند انقطاع الإنترنت ويرسلها تلقائياً عند عودته.
/// البيانات: friendships/{uidA_uidB} (members مرتّبة)، chats/{pairId}/messages، blocks/{uid}/list/{target}، reports.
class SocialService {
  static FirebaseFirestore get _db => FirebaseFirestore.instance;
  static String get me => AuthService.user!.uid;
  static String? get safeMe => AuthService.user?.uid;

  static String pairOf(String a, String b) => a.compareTo(b) < 0 ? '${a}_$b' : '${b}_$a';

  static Stream<List<QueryDocumentSnapshot<Map<String, dynamic>>>> _mine() =>
      _db.collection('friendships').where('members', arrayContains: me).snapshots().map((s) => s.docs);

  static Stream<List<FriendInfo>> friends() => _mine().map((docs) {
        final out = <FriendInfo>[];
        for (final d in docs) {
          final m = d.data();
          if (m['status'] != 'accepted') continue;
          final other = (m['members'] as List).cast<String>().firstWhere((x) => x != me);
          out.add(FriendInfo(other, d.id, ((m['names'] as Map)[other] ?? '?') as String));
        }
        return out;
      });

  static Stream<List<RequestInfo>> incoming() => _mine().map((docs) {
        final out = <RequestInfo>[];
        for (final d in docs) {
          final m = d.data();
          if (m['status'] != 'pending' || m['requester'] == me) continue;
          out.add(RequestInfo(d.id, ((m['names'] as Map)[m['requester']] ?? '?') as String));
        }
        return out;
      });

  /// يعيد null عند النجاح، أو: notfound / self / exists / error
  static Future<String?> sendRequest(String raw) async {
    final name = raw.trim().toLowerCase();
    if (name.isEmpty) return 'notfound';
    try {
      final u = await _db.collection('usernames').doc(name).get();
      if (!u.exists) return 'notfound';
      final other = u.data()!['uid'] as String;
      if (other == me) return 'self';
      final ref = _db.collection('friendships').doc(pairOf(me, other));
      if ((await ref.get()).exists) return 'exists';
      final members = [me, other]..sort();
      await ref.set({
        'members': members,
        'requester': me,
        'status': 'pending',
        'names': {me: AuthService.username, other: name},
        'createdAt': FieldValue.serverTimestamp(),
      });
      return null;
    } catch (_) {
      return 'error';
    }
  }

  static Future<void> accept(String pid) => _db.collection('friendships').doc(pid).update({'status': 'accepted'});
  static Future<void> removeFriendship(String pid) => _db.collection('friendships').doc(pid).delete();

  static Future<void> block(FriendInfo f) async {
    final b = _db.batch();
    b.set(_db.collection('blocks').doc(me).collection('list').doc(f.uid), {'at': FieldValue.serverTimestamp()});
    b.delete(_db.collection('friendships').doc(f.pairId));
    await b.commit();
  }

  static Future<void> report(String targetUid, String reason) =>
      _db.collection('reports').add({'by': me, 'target': targetUid, 'reason': reason, 'at': FieldValue.serverTimestamp()});

  /// كتابة رسالة بمعرّفها (idempotent). تكتمل عند وصولها للخادم؛ وعند انقطاع الإنترنت يحتفظ بها Firestore ويرسلها لاحقاً.
  static Future<void> putMessage(String pid, String id, String text, int ts) => _db
      .collection('chats').doc(pid).collection('messages').doc(id)
      .set({'from': me, 'text': text, 'ts': Timestamp.fromMillisecondsSinceEpoch(ts)});

  static Stream<QuerySnapshot<Map<String, dynamic>>> rawMessages(String pid) =>
      _db.collection('chats').doc(pid).collection('messages').orderBy('ts').snapshots(includeMetadataChanges: true);
}
