import 'dart:async';
import 'dart:convert';
import 'dart:typed_data';
import 'package:bluetooth_low_energy/bluetooth_low_energy.dart';
import 'package:flutter/foundation.dart';
import 'chat_repo.dart';
import 'crypto_service.dart';
import 'social_service.dart';

/// تواصل Bluetooth (BLE) بين أصدقاء قريبين دون إنترنت.
/// ⚠️ تجريبي وغير مُختبَر: هذا الملف وحده يستخدم مكتبة bluetooth_low_energy، وأسماء دوالها
/// تغيّرت بين إصداراتها. إن ظهرت أخطاء ترجمة هنا فعدّلها بحسب سجلّ تغييرات الإصدار الذي ثبّتّه.
/// التصميم: كل جهاز يعلن خدمة AURA ويستقبل (Peripheral)، ويمسح دورياً ويرسل (Central).
/// يتعرّف على الصديق بقراءة معرّفه، ولا يرسل إلا لأصدقاء مقبولين لديهم مفتاح عام مخزَّن.
/// الرسالة مشفّرة (CryptoService). حدّ النص 200 حرف. الترحيل عبر أجهزة وسيطة غير منفَّذ.
class BleService {
  static final _svc = UUID.fromString('9e2c0001-4a52-4f41-8a1e-5a0b1c2d3e4f');
  static final _idU = UUID.fromString('9e2c0002-4a52-4f41-8a1e-5a0b1c2d3e4f');
  static final _inU = UUID.fromString('9e2c0003-4a52-4f41-8a1e-5a0b1c2d3e4f');
  static const maxChars = 200;

  static bool running = false;
  static final status = ValueNotifier<String>('off');
  static final nearby = ValueNotifier<List<String>>([]); // أسماء الأصدقاء المرصودين في آخر مسح

  static Timer? _timer;
  static StreamSubscription<dynamic>? _wr, _disc;
  static bool _busy = false;
  static final List<Peripheral> _found = [];
  static CentralManager? _c;
  static PeripheralManager? _p;

  static Future<void> start() async {
    if (running || SocialService.safeMe == null) return;
    running = true;
    try {
      status.value = 'starting';
      final c = _c = CentralManager();
      final p = _p = PeripheralManager();
      await c.authorize(); // Android 12+: يطلب أذونات Bluetooth
      await p.authorize();
      final me = SocialService.me;
      final idC = GattCharacteristic.immutable(uuid: _idU, value: Uint8List.fromList(utf8.encode(me)), descriptors: []);
      final inC = GattCharacteristic.mutable(
          uuid: _inU, properties: [GattCharacteristicProperty.write], permissions: [GattCharacteristicPermission.write], descriptors: []);
      await p.addService(GattService(uuid: _svc, isPrimary: true, includedServices: [], characteristics: [idC, inC]));
      _wr = p.characteristicWriteRequested.listen((e) async {
        await _onReceive(e.value);
        try {
          await p.sendWriteCharacteristicReply(e.central, characteristic: e.characteristic, id: e.id, offset: e.offset, status: true);
        } catch (_) {}
      });
      _disc = c.discovered.listen((e) {
        if (!_found.any((x) => x.uuid == e.peripheral.uuid)) { _found.add(e.peripheral); }
      });
      await p.startAdvertising(Advertisement(name: 'AURA', serviceUUIDs: [_svc]));
      status.value = 'on';
      _timer = Timer.periodic(const Duration(seconds: 25), (_) => _cycle());
      _cycle();
    } catch (e) {
      running = false;
      status.value = 'error: $e';
    }
  }

  static Future<void> stop() async {
    _timer?.cancel();
    await _wr?.cancel();
    await _disc?.cancel();
    try { await _p?.stopAdvertising(); } catch (_) {}
    try { await _c?.stopDiscovery(); } catch (_) {}
    running = false;
    _busy = false;
    nearby.value = [];
    status.value = 'off';
  }

  static void requestFlush() { if (running) _cycle(); }

  static Future<void> _cycle() async {
    if (!running || _busy) return;
    _busy = true;
    try {
      final c = _c!;
      _found.clear();
      await c.startDiscovery(serviceUUIDs: [_svc]);
      await Future<void>.delayed(const Duration(seconds: 6));
      await c.stopDiscovery();
      final seen = <String>[];
      for (final per in List<Peripheral>.of(_found)) {
        final u = await _talk(per);
        if (u != null) seen.add(u);
      }
      nearby.value = seen;
    } catch (e) {
      status.value = 'error: $e';
    } finally {
      _busy = false;
    }
  }

  static Future<String?> _talk(Peripheral per) async {
    final c = _c!, s = ChatRepo.store;
    if (s == null) return null;
    try {
      await c.connect(per);
      final services = await c.discoverGATT(per);
      final svc = services.firstWhere((x) => x.uuid == _svc);
      final idC = svc.characteristics.firstWhere((x) => x.uuid == _idU);
      final inC = svc.characteristics.firstWhere((x) => x.uuid == _inU);
      final uid = utf8.decode(await c.readCharacteristic(per, idC));
      final peer = await s.peer(uid);
      if (peer == null) return null; // ليس صديقاً مقبولاً
      final pk = peer['pk'] as String?;
      final pid = peer['pid'] as String;
      if (pk != null) {
        for (final m in await s.pendingTo(pid, SocialService.me)) {
          if ((m['text'] as String).length > maxChars) continue;
          final env = await _envelope(m, uid, pk);
          await c.writeCharacteristic(per, inC, value: env, type: GattCharacteristicWriteType.withResponse);
          await s.setLStatus(m['id'] as String, 'ble');
          ChatRepo.notify(pid);
        }
      }
      return peer['username'] as String;
    } catch (_) {
      return null;
    } finally {
      try { await c.disconnect(per); } catch (_) {}
    }
  }

  static Future<Uint8List> _envelope(Map<String, Object?> m, String to, String pk) async {
    final id = m['id'] as String, ts = m['ts'] as int, from = SocialService.me;
    final ct = await CryptoService.encrypt(pk, m['text'] as String, '$id|$from|$to|$ts');
    return Uint8List.fromList(utf8.encode(jsonEncode({'i': id, 'f': from, 't': to, 's': ts, 'c': ct})));
  }

  static Future<void> _onReceive(Uint8List data) async {
    try {
      final j = jsonDecode(utf8.decode(data)) as Map<String, dynamic>;
      final id = j['i'] as String, from = j['f'] as String, to = j['t'] as String, ts = j['s'] as int;
      if (to != SocialService.me) return; // رسائل الآخرين تُهمل (الترحيل غير منفَّذ)
      final s = ChatRepo.store;
      if (s == null) return;
      final peer = await s.peer(from);
      final pk = peer?['pk'] as String?;
      if (peer == null || pk == null) return;
      final text = await CryptoService.decrypt(pk, j['c'] as String, '$id|$from|$to|$ts');
      if (text == null) return; // توقيع/مفتاح غير صالح: يُرفض
      final pid = peer['pid'] as String;
      await s.addLocalMsg({'id': id, 'pid': pid, 'from_uid': from, 'text': text, 'ts': ts, 'status': 'ble'});
      ChatRepo.notify(pid);
    } catch (_) {}
  }
}
