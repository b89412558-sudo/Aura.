import 'package:flutter/material.dart';

/// بيانات تجريبية مؤقتة حتى يُربط الخادم (المرحلة 3).
const kUsers = [
  ('sara', 'سارة', 'Sara', '🌌'), ('omar', 'عمر', 'Omar', '🚀'),
  ('lina', 'لينا', 'Lina', '🎨'), ('khalid', 'خالد', 'Khalid', '🎧'),
  ('noor', 'نور', 'Noor', '📸'), ('yousef', 'يوسف', 'Yousef', '🌠'),
];
const kGrad = [
  [Color(0xFF2F6BFF), Color(0xFF7B3FE4)], [Color(0xFF00C8E0), Color(0xFF2F6BFF)],
  [Color(0xFF7B3FE4), Color(0xFFC9B8FF)], [Color(0xFF00C8E0), Color(0xFF7B3FE4)],
];

String uname(BuildContext c, int i) =>
    Localizations.localeOf(c).languageCode == 'ar' ? kUsers[i].$2 : kUsers[i].$3;

/// صورة رمزية دائرية. i = -1 تعني المستخدم الحالي.
class Av extends StatelessWidget {
  const Av(this.i, this.size, {super.key});
  final int i;
  final double size;
  @override
  Widget build(BuildContext c) => Container(
        width: size, height: size, alignment: Alignment.center,
        decoration: BoxDecoration(shape: BoxShape.circle, gradient: LinearGradient(colors: kGrad[(i + 4) % 4])),
        child: Text(i < 0 ? 'A' : uname(c, i)[0],
            style: TextStyle(color: Colors.white, fontWeight: FontWeight.bold, fontSize: size / 2.4)),
      );
}

/// عمر "آخر نشاط" بالدقائق للأصدقاء التجريبيين (لترتيب الكوكبة).
const kAges = [5, 20, 60, 120, 240, 540];
