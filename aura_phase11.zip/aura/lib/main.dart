import 'package:firebase_core/firebase_core.dart';
import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';
import 'package:provider/provider.dart';
import 'core/auth_service.dart';
import 'firebase_options.dart';
import 'core/chat_repo.dart';
import 'core/local_store.dart';
import 'core/settings.dart';
import 'core/state.dart';
import 'core/theme.dart';
import 'core/strings.dart';
import 'core/router.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();
  final settings = await AppSettings.load();
  LocalStore? store;
  try { store = await LocalStore.open(); } catch (_) { store = null; } // دون قاعدة محلية: وضع الذاكرة فقط
  final app = AppState();
  await app.load(store);
  ChatRepo.store = store;
  try {
    await Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform); // يرمي خطأً إن لم يُضبط Firebase فنبقى في الوضع التجريبي
    AuthService.ready = true;
    await AuthService.refreshUsername();
  } catch (_) {
    AuthService.ready = false; // Firebase غير مُعدّ بعد: وضع تجريبي بلا حسابات
  }
  runApp(MultiProvider(
    providers: [
      ChangeNotifierProvider.value(value: settings),
      ChangeNotifierProvider.value(value: app),
    ],
    child: AuraApp(),
  ));
}

class AuraApp extends StatelessWidget {
  AuraApp({super.key});
  final _router = buildRouter();
  @override
  Widget build(BuildContext context) {
    final s = context.watch<AppSettings>();
    return MaterialApp.router(
      title: 'AURA',
      debugShowCheckedModeBanner: false,
      theme: AuraTheme.light,
      darkTheme: AuraTheme.dark,
      themeMode: s.themeMode,
      locale: s.locale,
      supportedLocales: const [Locale('ar'), Locale('en')],
      localizationsDelegates: const [
        GlobalMaterialLocalizations.delegate,
        GlobalWidgetsLocalizations.delegate,
        GlobalCupertinoLocalizations.delegate,
      ],
      routerConfig: _router,
      builder: (c, child) => Directionality(
        textDirection: Str.isRtl(s.locale) ? TextDirection.rtl : TextDirection.ltr,
        child: child!,
      ),
    );
  }
}
